package com.noads.vip.pass;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import org.jf.dexlib2.DexFileFactory;
import org.jf.dexlib2.iface.ClassDef;
import org.jf.dexlib2.iface.DexFile;
import org.jf.dexlib2.iface.Field;
import org.jf.dexlib2.iface.Method;
import org.jf.dexlib2.iface.instruction.Instruction;
import org.jf.dexlib2.iface.instruction.ReferenceInstruction;
import org.jf.dexlib2.iface.reference.Reference;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Locale;

import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class DexAnalyzer {

    public interface Callback {

        void onDexFound(String dexName);

        void onResult(DexSearchResult result);

        void onFinished(int total);

        void onError(Exception e);
    }

    // =========================================================
    // ANALIZAR APK
    // =========================================================

    public static void analyze(
            Context context,
            Uri apkUri,
            Callback callback) {

        new Thread(() -> {

            File apk = null;

            try {

                apk = copyToCache(
                        context,
                        apkUri
                );

                int total = 0;

                try (ZipFile zip = new ZipFile(apk)) {

                    List<String> dexFiles =
                            findDexFiles(zip);

                    if (dexFiles.isEmpty()) {

                        throw new Exception(
                                "No se encontraron archivos DEX"
                        );
                    }

                    /*
                     * =================================================
                     * ANALIZAR CADA DEX
                     * =================================================
                     */

                    for (String dexName : dexFiles) {

                        callback.onDexFound(
                                dexName
                        );

                        File dexFile =
                                extractDex(
                                        context,
                                        zip,
                                        dexName
                                );

                        try {

                            DexFile dex =
                                    DexFileFactory.loadDexFile(
                                            dexFile,
                                            null
                                    );

                            Map<String, DexSearchResult> grouped =
                                    new LinkedHashMap<>();

                            /*
                             * =================================================
                             * ANALIZAR CLASES
                             * =================================================
                             */

                            for (ClassDef cls :
                                    dex.getClasses()) {

                                String className =
                                        cls.getType();

                                /*
                                 * -----------------------------------------
                                 * 1. Clase inválida
                                 * -----------------------------------------
                                 */

                                if (className == null) {
                                    continue;
                                }

                                /*
                                 * -----------------------------------------
                                 * 2. Librerías externas
                                 * -----------------------------------------
                                 */

                                if (
                                        isLibraryClass(
                                                className
                                        )
                                ) {
                                    continue;
                                }

                                /*
                                 * -----------------------------------------
                                 * 3. Clases generadas R
                                 *
                                 * R
                                 * R$id
                                 * R$layout
                                 * R$string
                                 * R$drawable
                                 * R$color
                                 * etc.
                                 *
                                 * NO contienen lógica VIP.
                                 * -----------------------------------------
                                 */

                                if (
                                        isGeneratedResourceClass(
                                                className
                                        )
                                ) {
                                    continue;
                                }

                                /*
                                 * -----------------------------------------
                                 * 4. Clases ignoradas
                                 * -----------------------------------------
                                 */

                                if (
                                        isIgnoredClass(
                                                className
                                        )
                                ) {
                                    continue;
                                }

                                /*
                                 * -----------------------------------------
                                 * 5. Analizar clase
                                 * -----------------------------------------
                                 */

                                analyzeClass(
                                        cls,
                                        dexName,
                                        grouped
                                );
                            }

                            /*
                             * =================================================
                             * RESULTADOS
                             * =================================================
                             */

                            List<DexSearchResult> results =
                                    new ArrayList<>(
                                            grouped.values()
                                    );

                            /*
                             * =================================================
                             * ORDENAR
                             *
                             * Primero:
                             *   estado VIP directo
                             *
                             * Después:
                             *   servicios / API
                             *
                             * Después:
                             *   billing / subscription
                             *
                             * Después:
                             *   indicadores débiles
                             * =================================================
                             */

                            results.sort(
                                    (a, b) -> {

                                        int scoreA =
                                                a.getPremiumScore();

                                        int scoreB =
                                                b.getPremiumScore();

                                        /*
                                         * Mayor puntuación primero.
                                         */

                                        int compare =
                                                Integer.compare(
                                                        scoreB,
                                                        scoreA
                                                );

                                        if (compare != 0) {
                                            return compare;
                                        }

                                        /*
                                         * En empate, priorizar clases
                                         * que tengan métodos.
                                         */

                                        int methodsA =
                                                a.getMethods().size()
                                                +
                                                a.getGetters().size()
                                                +
                                                a.getSetters().size();

                                        int methodsB =
                                                b.getMethods().size()
                                                +
                                                b.getGetters().size()
                                                +
                                                b.getSetters().size();

                                        compare =
                                                Integer.compare(
                                                        methodsB,
                                                        methodsA
                                                );

                                        if (compare != 0) {
                                            return compare;
                                        }

                                        /*
                                         * Finalmente ordenar por nombre
                                         * para mantener resultados estables.
                                         */

                                        return a.className.compareToIgnoreCase(
                                                b.className
                                        );
                                    }
                            );

                            /*
                             * =================================================
                             * ENVIAR RESULTADOS
                             * =================================================
                             */

                            for (DexSearchResult result :
                                    results) {

                                int score =
                                        result.getPremiumScore();

                                /*
                                 * No mostrar basura.
                                 */

                                if (
                                        result.isEmpty()
                                        || score <= 0
                                ) {
                                    continue;
                                }

                                callback.onResult(
                                        result
                                );

                                total++;
                            }

                        } finally {

                            if (dexFile.exists()) {
                                dexFile.delete();
                            }
                        }
                    }
                }

                /*
                 * =================================================
                 * LIMPIAR APK TEMPORAL
                 * =================================================
                 */

                if (apk.exists()) {
                    apk.delete();
                }

                postFinished(
                        callback,
                        total
                );

            } catch (Exception e) {

                if (apk != null && apk.exists()) {
                    apk.delete();
                }

                postError(
                        callback,
                        e
                );
            }

        }).start();
    }

    // =========================================================
    // ANALIZAR CLASE
    // =========================================================

    private static void analyzeClass(
            ClassDef cls,
            String dexName,
            Map<String, DexSearchResult> grouped) {

        String className =
                cls.getType();

        /*
         * Protección adicional.
         */

        if (
                className == null
                || isGeneratedResourceClass(className)
        ) {
            return;
        }

        // =====================================================
        // CAMPOS
        // =====================================================

        for (Field field : cls.getFields()) {

            if (field == null) {
                continue;
            }

            String fieldName =
                    field.getName();

            String fieldType =
                    field.getType();

            /*
             * Analizar nombre y tipo.
             *
             * Importante:
             * NO usamos field.toString() como única fuente,
             * porque puede contener el nombre del paquete.
             */

            String searchable =
                    fieldName
                            + ":"
                            + fieldType;

            if (
                    !DexSearchResult
                            .isPremiumIndicator(
                                    searchable
                            )
            ) {
                continue;
            }

            DexSearchResult result =
                    getResult(
                            grouped,
                            dexName,
                            className
                    );

            /*
             * Guardamos una representación limpia.
             *
             * Ejemplo:
             *
             * vip:Z
             */

            result.addField(
                    fieldName
                            + ":"
                            + fieldType
            );
        }

        // =====================================================
        // MÉTODOS
        // =====================================================

        for (Method method : cls.getMethods()) {

            if (method == null) {
                continue;
            }

            String methodName =
                    method.getName();

            if (methodName == null) {
                continue;
            }

            /*
             * Los constructores no son evidencia VIP.
             */

            if (
                    methodName.equals("<init>")
                    ||
                    methodName.equals("<clinit>")
            ) {

                /*
                 * Aun así analizamos las instrucciones
                 * del método si existen.
                 *
                 * Un constructor podría llamar a un método
                 * de suscripción.
                 */

            }

            /*
             * Firma.
             */

            String signature =
                    method.toString();

            /*
             * -----------------------------------------------------
             * Determinar si el propio método es importante.
             * -----------------------------------------------------
             */

            boolean methodMatch =
                    DexSearchResult
                            .isPremiumIndicator(
                                    methodName
                            );

            if (!methodMatch) {

                methodMatch =
                        DexSearchResult
                                .isPremiumIndicator(
                                        getCleanMethodSignature(
                                                method
                                        )
                                );
            }

            if (methodMatch) {

                DexSearchResult result =
                        getResult(
                                grouped,
                                dexName,
                                className
                        );

                String lower =
                        methodName.toLowerCase(
                                Locale.ROOT
                        );

                /*
                 * IMPORTANTE:
                 *
                 * Solamente clasificar como getter/setter
                 * cuando realmente empieza con get/set.
                 */

                if (
                        lower.startsWith("get")
                        &&
                        !lower.equals("get")
                ) {

                    result.addGetter(
                            signature
                    );

                } else if (
                        lower.startsWith("set")
                        &&
                        !lower.equals("set")
                ) {

                    result.addSetter(
                            signature
                    );

                } else {

                    result.addMethod(
                            signature
                    );
                }
            }

            // =====================================================
            // REFERENCIAS
            // =====================================================

            if (
                    method.getImplementation() == null
            ) {
                continue;
            }

            for (
                    Instruction instruction :
                    method.getImplementation()
                            .getInstructions()
            ) {

                if (
                        !(instruction
                                instanceof ReferenceInstruction)
                ) {
                    continue;
                }

                ReferenceInstruction
                        refInstruction =
                        (ReferenceInstruction)
                                instruction;

                Reference reference =
                        refInstruction
                                .getReference();

                if (reference == null) {
                    continue;
                }

                String referenceText =
                        reference.toString();

                /*
                 * -------------------------------------------------
                 * IMPORTANTE
                 *
                 * DexSearchResult ya elimina el nombre del
                 * paquete al analizar la referencia.
                 *
                 * Así:
                 *
                 * Lcom/noads/mod/User;->isVip()Z
                 *
                 * se interpreta por:
                 *
                 * isVip()Z
                 *
                 * y NO por "noads".
                 * -------------------------------------------------
                 */

                if (
                        !DexSearchResult
                                .isPremiumIndicator(
                                        referenceText
                                )
                ) {
                    continue;
                }

                DexSearchResult result =
                        getResult(
                                grouped,
                                dexName,
                                className
                        );

                /*
                 * Limpiar referencia para mostrar
                 * una relación más entendible.
                 */

                String cleanReference =
                        cleanReference(
                                referenceText
                        );

                result.addReference(
                        methodName
                                + "() -> "
                                + cleanReference
                );
            }
        }
    }

    // =========================================================
    // FIRMA LIMPIA DEL MÉTODO
    // =========================================================

    private static String getCleanMethodSignature(
            Method method) {

        if (method == null) {
            return "";
        }

        String name =
                method.getName();

        if (name == null) {
            return "";
        }

        /*
         * Para el detector es suficiente el nombre.
         */

        return name;
    }

    // =========================================================
    // LIMPIAR REFERENCIA
    // =========================================================

    private static String cleanReference(
            String reference) {

        if (reference == null) {
            return "";
        }

        String value =
                reference.trim();

        /*
         * Ejemplo:
         *
         * Lcom/noads/mod/User;->isVip()Z
         *
         * se mantiene útil, pero eliminamos
         * ruido innecesario cuando sea posible.
         */

        int arrow =
                value.indexOf("->");

        if (arrow >= 0) {

            String owner =
                    value.substring(
                            0,
                            arrow
                    );

            String member =
                    value.substring(
                            arrow + 2
                    );

            /*
             * Convertir descriptor:
             *
             * Lcom/noads/mod/User;
             *
             * a:
             *
             * User
             */

            int slash =
                    owner.lastIndexOf('/');

            if (slash >= 0) {

                owner =
                        owner.substring(
                                slash + 1
                        );
            }

            if (
                    owner.startsWith("L")
            ) {
                owner =
                        owner.substring(1);
            }

            if (
                    owner.endsWith(";")
            ) {
                owner =
                        owner.substring(
                                0,
                                owner.length() - 1
                        );
            }

            return owner
                    + "->"
                    + member;
        }

        return value;
    }

    // =========================================================
    // CLASES R / RECURSOS GENERADOS
    // =========================================================

    private static boolean isGeneratedResourceClass(
            String className) {

        if (className == null) {
            return true;
        }

        String simple =
                getSimpleClassName(
                        className
                );

        /*
         * R
         * R$id
         * R$layout
         * R$string
         * R$drawable
         * R$color
         * R$style
         * etc.
         */

        return simple.equals("R")
                || simple.startsWith("R$");
    }

    private static String getSimpleClassName(
            String className) {

        if (className == null) {
            return "";
        }

        String value =
                className;

        int slash =
                value.lastIndexOf('/');

        if (slash >= 0) {

            value =
                    value.substring(
                            slash + 1
                    );
        }

        if (
                value.startsWith("L")
        ) {
            value =
                    value.substring(1);
        }

        if (
                value.endsWith(";")
        ) {

            value =
                    value.substring(
                            0,
                            value.length() - 1
                    );
        }

        return value;
    }

    // =========================================================
    // IGNORAR LIBRERÍAS
    // =========================================================

    private static boolean isLibraryClass(
            String className) {

        if (className == null) {
            return true;
        }

        String value =
                className.toLowerCase(
                        Locale.ROOT
                );

        String[] libraries = {

                /*
                 * Android
                 */
                "landroid/",

                /*
                 * Java
                 */
                "ljava/",
                "ljavax/",
                "ljakarta/",

                /*
                 * AndroidX
                 */
                "landroidx/",

                /*
                 * Kotlin
                 */
                "lkotlin/",
                "lkotlinx/",

                /*
                 * Google Play Services
                 */
                "lcom/google/android/gms/",

                /*
                 * Google
                 */
                "lcom/google/android/",

                /*
                 * Google general
                 */
                "lcom/google/",

                /*
                 * Firebase
                 */
                "lcom/google/firebase/",

                /*
                 * Play Billing
                 */
                "lcom/android/billingclient/",

                /*
                 * Facebook
                 */
                "lcom/facebook/",

                /*
                 * Glide
                 */
                "lcom/bumptech/glide/",

                /*
                 * OkHttp
                 */
                "lokhttp3/",

                /*
                 * Retrofit
                 */
                "lretrofit2/",

                /*
                 * Apache
                 */
                "lorg/apache/",

                /*
                 * JSON
                 */
                "lorg/json/"
        };

        for (String library : libraries) {

            if (value.startsWith(library)) {
                return true;
            }
        }

        return false;
    }

    // =========================================================
    // IGNORAR CLASES ESPECÍFICAS
    // =========================================================

    private static boolean isIgnoredClass(
            String className) {

        if (className == null) {
            return true;
        }

        String value =
                className.toLowerCase(
                        Locale.ROOT
                );

        String[] ignored = {

                /*
                 * Google
                 */
                "lcom/google/android/gms/measurement/",
                "lcom/google/android/gms/ads/",
                "lcom/google/android/gms/common/",
                "lcom/google/android/gms/tasks/",
                "lcom/google/android/gms/base/",
                "lcom/google/android/gms/stats/",
                "lcom/google/android/gms/dynamite/",
                "lcom/google/android/gms/internal/",

                /*
                 * Firebase
                 */
                "lcom/google/firebase/",

                /*
                 * Billing
                 */
                "lcom/android/billingclient/",

                /*
                 * AndroidX
                 */
                "landroidx/"
        };

        for (String prefix : ignored) {

            if (value.startsWith(prefix)) {
                return true;
            }
        }

        return false;
    }

    // =========================================================
    // BUSCAR DEX
    // =========================================================

    private static List<String> findDexFiles(
            ZipFile zip) {

        List<String> result =
                new ArrayList<>();

        Enumeration<? extends ZipEntry> entries =
                zip.entries();

        while (entries.hasMoreElements()) {

            ZipEntry entry =
                    entries.nextElement();

            String name =
                    entry.getName();

            if (
                    name.matches(
                            "classes(\\d*)?\\.dex"
                    )
            ) {

                result.add(name);
            }
        }

        return result;
    }

    // =========================================================
    // RESULTADO
    // =========================================================

    private static DexSearchResult getResult(
            Map<String, DexSearchResult> map,
            String dexName,
            String className) {

        String key =
                dexName
                        + "|"
                        + className;

        DexSearchResult result =
                map.get(key);

        if (result == null) {

            result =
                    new DexSearchResult(
                            dexName,
                            className
                    );

            map.put(
                    key,
                    result
            );
        }

        return result;
    }

    // =========================================================
    // COPIAR APK
    // =========================================================

    private static File copyToCache(
            Context context,
            Uri uri)
            throws Exception {

        File file =
                new File(
                        context.getCacheDir(),
                        "vip_pass_selected.apk"
                );

        InputStream input =
                context.getContentResolver()
                        .openInputStream(uri);

        if (input == null) {

            throw new Exception(
                    "No se pudo abrir el APK"
            );
        }

        try (
                InputStream in = input;
                FileOutputStream output =
                        new FileOutputStream(file)
        ) {

            byte[] buffer =
                    new byte[8192];

            int read;

            while (
                    (read =
                            in.read(buffer)) != -1
            ) {

                output.write(
                        buffer,
                        0,
                        read
                );
            }
        }

        return file;
    }

    // =========================================================
    // EXTRAER DEX
    // =========================================================

    private static File extractDex(
            Context context,
            ZipFile zip,
            String dexName)
            throws Exception {

        ZipEntry entry =
                zip.getEntry(dexName);

        if (entry == null) {

            throw new Exception(
                    "No se encontró "
                            + dexName
            );
        }

        File dex =
                new File(
                        context.getCacheDir(),
                        dexName
                                + "_vip_pass"
                );

        try (
                InputStream input =
                        zip.getInputStream(entry);

                FileOutputStream output =
                        new FileOutputStream(dex)
        ) {

            byte[] buffer =
                    new byte[8192];

            int read;

            while (
                    (read =
                            input.read(buffer)) != -1
            ) {

                output.write(
                        buffer,
                        0,
                        read
                );
            }
        }

        return dex;
    }

    // =========================================================
    // CALLBACKS
    // =========================================================

    private static void postFinished(
            Callback callback,
            int total) {

        Handler handler =
                new Handler(
                        Looper.getMainLooper()
                );

        handler.post(() ->
                callback.onFinished(total)
        );
    }

    private static void postError(
            Callback callback,
            Exception error) {

        Handler handler =
                new Handler(
                        Looper.getMainLooper()
                );

        handler.post(() ->
                callback.onError(error)
        );
    }
}