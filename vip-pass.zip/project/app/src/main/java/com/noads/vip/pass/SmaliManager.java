package com.noads.vip.pass;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.jf.baksmali.Baksmali;
import org.jf.baksmali.BaksmaliOptions;
import org.jf.dexlib2.DexFileFactory;
import org.jf.dexlib2.iface.DexFile;

public class SmaliManager {

    private final int apiLevel;

    public SmaliManager() {
        this(35);
    }

    public SmaliManager(int apiLevel) {
        this.apiLevel = apiLevel;
    }

    // =========================================================
    // DEX -> SMALI
    // =========================================================

    public void disassemble(
            File dexFile,
            File outputDirectory
    ) throws Exception {

        if (dexFile == null
                || !dexFile.exists()
                || !dexFile.isFile()) {

            throw new Exception(
                    "DEX no encontrado:\n"
                            + (
                            dexFile != null
                                    ? dexFile.getAbsolutePath()
                                    : "null"
                    )
            );
        }

        if (dexFile.length() == 0) {

            throw new Exception(
                    "El DEX está vacío."
            );
        }

        if (outputDirectory == null) {

            throw new Exception(
                    "Directorio Smali inválido."
            );
        }

        // -----------------------------------------------------
        // CREAR DIRECTORIO
        // -----------------------------------------------------

        if (!outputDirectory.exists()) {

            if (!outputDirectory.mkdirs()
                    && !outputDirectory.exists()) {

                throw new Exception(
                        "No se pudo crear:\n"
                                + outputDirectory.getAbsolutePath()
                );
            }
        }

        // -----------------------------------------------------
        // LIMPIAR SMALI ANTERIOR
        // -----------------------------------------------------

        deleteSmaliFiles(
                outputDirectory
        );

        // -----------------------------------------------------
        // CARGAR DEX
        // -----------------------------------------------------

        DexFile dex;

        try {

            dex =
                    DexFileFactory.loadDexFile(
                            dexFile,
                            null
                    );

        } catch (Exception e) {

            throw new Exception(
                    "El DEX original no es válido:\n"
                            + e.getMessage(),
                    e
            );
        }

        // -----------------------------------------------------
        // OPCIONES BAKSMALI
        // -----------------------------------------------------

        BaksmaliOptions options =
                new BaksmaliOptions();

        options.apiLevel =
                apiLevel;

        /*
         * Mantener referencias completas.
         */
        options.implicitReferences =
                false;

        /*
         * Mantener información de debug.
         */
        options.debugInfo =
                true;

        /*
         * No generar información adicional
         * de registros.
         */
        options.registerInfo =
                0;

        // -----------------------------------------------------
        // DESENSAMBLAR
        // -----------------------------------------------------

        boolean result;

        try {

            result =
                    Baksmali.disassembleDexFile(
                            dex,
                            outputDirectory,
                            Runtime.getRuntime()
                                    .availableProcessors(),
                            options
                    );

        } catch (Exception e) {

            throw new Exception(
                    "Baksmali produjo un error:\n"
                            + e.getMessage(),
                    e
            );
        }

        if (!result) {

            throw new Exception(
                    "Baksmali no pudo desensamblar el DEX."
            );
        }

        // -----------------------------------------------------
        // COMPROBAR SMALI
        // -----------------------------------------------------

        List<String> files =
                new ArrayList<String>();

        collectSmaliFiles(
                outputDirectory,
                files
        );

        if (files.isEmpty()) {

            throw new Exception(
                    "Baksmali terminó pero no generó archivos .smali."
            );
        }
    }

    // =========================================================
    // SMALI -> DEX
    // =========================================================

    public void assemble(
            File smaliDirectory,
            File outputDex
    ) throws Exception {

        if (smaliDirectory == null
                || !smaliDirectory.exists()
                || !smaliDirectory.isDirectory()) {

            throw new Exception(
                    "Directorio Smali no encontrado."
            );
        }

        if (outputDex == null) {

            throw new Exception(
                    "DEX de salida inválido."
            );
        }

        // -----------------------------------------------------
        // BUSCAR SMALI
        // -----------------------------------------------------

        List<String> files =
                new ArrayList<String>();

        collectSmaliFiles(
                smaliDirectory,
                files
        );

        if (files.isEmpty()) {

            throw new Exception(
                    "No se encontraron archivos .smali."
            );
        }

        // -----------------------------------------------------
        // ELIMINAR DEX ANTERIOR
        // -----------------------------------------------------

        if (outputDex.exists()) {

            if (!outputDex.delete()) {

                throw new Exception(
                        "No se pudo eliminar el DEX anterior:\n"
                                + outputDex.getAbsolutePath()
                );
            }
        }

        // -----------------------------------------------------
        // ASSEMBLER
        // -----------------------------------------------------

        assembleUsingSmaliApi(
                files,
                outputDex
        );

        // -----------------------------------------------------
        // COMPROBAR ARCHIVO
        // -----------------------------------------------------

        if (!outputDex.exists()) {

            throw new Exception(
                    "Smali no creó el DEX."
            );
        }

        if (outputDex.length() == 0) {

            throw new Exception(
                    "Smali creó un DEX vacío."
            );
        }

        // -----------------------------------------------------
        // VALIDAR DEX REAL
        // -----------------------------------------------------

        validateDex(
                outputDex
        );
    }

    // =========================================================
    // VALIDAR DEX
    // =========================================================

    private void validateDex(
            File dexFile
    ) throws Exception {

        try {

            DexFileFactory.loadDexFile(
                    dexFile,
                    null
            );

        } catch (Exception e) {

            throw new Exception(
                    "El DEX generado por Smali no es válido.\n\n"
                            + "Archivo:\n"
                            + dexFile.getAbsolutePath()
                            + "\n\n"
                            + "Error:\n"
                            + e.getMessage(),
                    e
            );
        }
    }

    // =========================================================
    // BUSCAR .SMALI
    // =========================================================

    private void collectSmaliFiles(
            File directory,
            List<String> result
    ) {

        if (directory == null
                || result == null) {

            return;
        }

        File[] files =
                directory.listFiles();

        if (files == null) {

            return;
        }

        for (File file : files) {

            if (file == null) {
                continue;
            }

            if (file.isDirectory()) {

                collectSmaliFiles(
                        file,
                        result
                );

            } else {

                String name =
                        file.getName()
                                .toLowerCase();

                if (name.endsWith(".smali")) {

                    result.add(
                            file.getAbsolutePath()
                    );
                }
            }
        }
    }

    // =========================================================
    // LIMPIAR ARCHIVOS SMALI
    // =========================================================

    private void deleteSmaliFiles(
            File directory
    ) {

        if (directory == null
                || !directory.exists()) {

            return;
        }

        File[] files =
                directory.listFiles();

        if (files == null) {
            return;
        }

        for (File file : files) {

            if (file == null) {
                continue;
            }

            if (file.isDirectory()) {

                deleteSmaliFiles(
                        file
                );

                File[] children =
                        file.listFiles();

                if (children != null
                        && children.length == 0) {

                    file.delete();
                }

            } else {

                String name =
                        file.getName()
                                .toLowerCase();

                if (name.endsWith(".smali")) {

                    file.delete();
                }
            }
        }
    }

    // =========================================================
    // ASSEMBLER
    // =========================================================

    private void assembleUsingSmaliApi(
            List<String> files,
            File outputDex
    ) throws Exception {

        // -----------------------------------------------------
        // CARGAR SmaliOptions
        // -----------------------------------------------------

        Class<?> optionsClass;

        try {

            optionsClass =
                    Class.forName(
                            "org.jf.smali.SmaliOptions"
                    );

        } catch (ClassNotFoundException e) {

            throw new Exception(
                    "No se encontró org.jf.smali.SmaliOptions.\n"
                            + "Comprueba que smali 2.5.2 esté incluido.",
                    e
            );
        }

        Object options =
                optionsClass
                        .getDeclaredConstructor()
                        .newInstance();

        // -----------------------------------------------------
        // OUTPUT DEX
        // -----------------------------------------------------

        try {

            java.lang.reflect.Field field =
                    optionsClass.getField(
                            "outputDexFile"
                    );

            field.set(
                    options,
                    outputDex.getAbsolutePath()
            );

        } catch (NoSuchFieldException e) {

            throw new Exception(
                    "SmaliOptions no contiene outputDexFile."
            );
        }

        // -----------------------------------------------------
        // API LEVEL
        // -----------------------------------------------------

        try {

            java.lang.reflect.Field field =
                    optionsClass.getField(
                            "apiLevel"
                    );

            field.setInt(
                    options,
                    apiLevel
            );

        } catch (NoSuchFieldException ignored) {
            // Algunas builds no exponen este campo.
        }

        // -----------------------------------------------------
        // VERBOSE ERRORS
        // -----------------------------------------------------

        try {

            java.lang.reflect.Field field =
                    optionsClass.getField(
                            "verboseErrors"
                    );

            field.setBoolean(
                    options,
                    true
            );

        } catch (NoSuchFieldException ignored) {
        }

        // -----------------------------------------------------
        // BUSCAR CLASE Smali
        // -----------------------------------------------------

        Class<?> smaliClass;

        try {

            smaliClass =
                    Class.forName(
                            "org.jf.smali.Smali"
                    );

        } catch (ClassNotFoundException e) {

            throw new Exception(
                    "No se encontró org.jf.smali.Smali.\n"
                            + "Comprueba que smali 2.5.2 esté incluido.",
                    e
            );
        }

        // -----------------------------------------------------
        // BUSCAR assemble(SmaliOptions, List)
        // -----------------------------------------------------

        java.lang.reflect.Method target =
                null;

        for (
                java.lang.reflect.Method method
                : smaliClass.getMethods()
        ) {

            if (!method.getName()
                    .equals("assemble")) {

                continue;
            }

            Class<?>[] params =
                    method.getParameterTypes();

            if (params.length != 2) {
                continue;
            }

            /*
             * Queremos específicamente:
             *
             * assemble(
             *     SmaliOptions,
             *     List
             * )
             */

            if (!params[0]
                    .isAssignableFrom(
                            optionsClass
                    )
                    &&
                    !optionsClass
                            .isAssignableFrom(
                                    params[0]
                            )) {

                continue;
            }

            if (!List.class
                    .isAssignableFrom(
                            params[1]
                    )) {

                continue;
            }

            target =
                    method;

            break;
        }

        if (target == null) {

            throw new Exception(
                    "No se encontró un método compatible:\n"
                            + "Smali.assemble(SmaliOptions, List)"
            );
        }

        // -----------------------------------------------------
        // EJECUTAR ASSEMBLER
        // -----------------------------------------------------

        Object result;

        try {

            result =
                    target.invoke(
                            null,
                            options,
                            files
                    );

        } catch (
                java.lang.reflect.InvocationTargetException e
        ) {

            Throwable cause =
                    e.getCause();

            String message =
                    cause != null
                            ? cause.getMessage()
                            : e.getMessage();

            throw new Exception(
                    "Smali no pudo compilar los archivos.\n\n"
                            + message,
                    cause != null
                            ? cause
                            : e
            );
        }

        // -----------------------------------------------------
        // RESULTADO BOOLEAN
        // -----------------------------------------------------

        if (result instanceof Boolean) {

            Boolean ok =
                    (Boolean) result;

            if (!ok) {

                throw new Exception(
                        "Smali devolvió false al compilar."
                );
            }
        }
    }
}