package com.noads.vip.pass;

import java.util.*;

public class DexSearchResult {

    public final String dexName;
    public final String className;

    private final Set<String> fields = new LinkedHashSet<>();
    private final Set<String> methods = new LinkedHashSet<>();
    private final Set<String> getters = new LinkedHashSet<>();
    private final Set<String> setters = new LinkedHashSet<>();
    private final Set<String> references = new LinkedHashSet<>();

    public DexSearchResult(String dexName, String className) {

        this.dexName = dexName == null ? "" : dexName;

        this.className = className == null ? "" : className;
    }

    // =========================================================
    // CAMPOS
    // =========================================================

    public void addField(String field) {

        if (field == null) {
            return;
        }

        String value = field.trim();

        if (!value.isEmpty()) {
            fields.add(value);
        }
    }

    // =========================================================
    // MÉTODOS
    // =========================================================

    public void addMethod(String method) {

        if (method == null) {
            return;
        }

        String value = method.trim();

        if (!value.isEmpty()) {
            methods.add(value);
        }
    }

    // =========================================================
    // GETTERS
    // =========================================================

    public void addGetter(String getter) {

        if (getter == null) {
            return;
        }

        String value = getter.trim();

        if (!value.isEmpty()) {
            getters.add(value);
        }
    }

    // =========================================================
    // SETTERS
    // =========================================================

    public void addSetter(String setter) {

        if (setter == null) {
            return;
        }

        String value = setter.trim();

        if (!value.isEmpty()) {
            setters.add(value);
        }
    }

    // =========================================================
    // REFERENCIAS
    // =========================================================

    public void addReference(String reference) {

        if (reference == null) {
            return;
        }

        String value = reference.trim();

        if (!value.isEmpty()) {
            references.add(value);
        }
    }

    // =========================================================
    // GETTERS PÚBLICOS
    // =========================================================

    public List<String> getFields() {
        return new ArrayList<>(fields);
    }

    public List<String> getMethods() {
        return new ArrayList<>(methods);
    }

    public List<String> getGetters() {
        return new ArrayList<>(getters);
    }

    public List<String> getSetters() {
        return new ArrayList<>(setters);
    }

    public List<String> getReferences() {
        return new ArrayList<>(references);
    }

    // =========================================================
    // RESULTADO VACÍO
    // =========================================================

    public boolean isEmpty() {

        return fields.isEmpty() && methods.isEmpty() && getters.isEmpty() && setters.isEmpty()
                && references.isEmpty();
    }

    // =========================================================
    // INDICADORES PREMIUM
    // =========================================================

    public static boolean isPremiumIndicator(String value) {

        if (value == null) {
            return false;
        }

        String text = value.toLowerCase(Locale.ROOT);

        /*
         * --------------------------------------------------------- IMPORTANTE:
         *
         * No buscamos solamente "vip".
         *
         * También reconocemos nombres habituales relacionados con estados Premium, membresías, suscripciones y compras. ---------------------------------------------------------
         */

        String[] indicators = {

                // Estados directos
                "isvip", "vip", "premium", "ispremium", "premiumstatus", "premiumstate",
                "premiumuser", "isvipuser", "vipuser",

                // Membresía
                "membership", "ismember", "member", "memberstatus", "subscription", "issubscribed",
                "subscribed", "subscriptionstatus", "subscriptionstate",

                // Pro
                "ispro", "prostatus", "prouser", "proaccount",

                // Plan
                "plan", "plantype", "subscriptionplan", "premiumplan", "vipplan",

                // Compra / acceso
                "purchase", "purchased", "ispurchased", "purchasehistory", "haspurchase",
                "haspurchased", "entitlement", "entitlements", "accesslevel", "premiumaccess",
                "vipaccess",

                // Suscripción
                "subscribe", "subscribed", "unsubscribe", "renew", "renewal", "renewsubscription",
                "autorenew",

                // Billing
                "billing", "billingclient", "productdetails", "productid", "productids", "sku",
                "skus", "inapp", "inappbilling",

                // Periodos
                "trial", "freetrial", "trialperiod", "expiration", "expires", "expiry",
                "expirationdate", "expirydate",

                // Acceso
                "premiumfeature", "premiumfeatures", "vipfeature", "vipfeatures", "unlock",
                "unlocked", "isunlocked", "locked", "hasaccess", "access",

                // Créditos / monedas de aplicaciones
                "premiumcoin", "premiumcoins", "vipcoin", "vipcoins" };

        /*
         * Primero comprobamos indicadores directos.
         */

        for (String indicator : indicators) {

            if (text.contains(indicator)) {
                return true;
            }
        }

        /*
         * --------------------------------------------------------- Formas habituales separadas:
         *
         * is_vip is-vip is.vip isVip ---------------------------------------------------------
         */

        String normalized = text.replace("_", "").replace("-", "").replace(".", "").replace("$",
                "");

        for (String indicator : indicators) {

            if (normalized.contains(indicator)) {
                return true;
            }
        }

        return false;
    }

    // =========================================================
    // PUNTUACIÓN PREMIUM
    // =========================================================

    public int getPremiumScore() {

        int score = 0;

        /*
         * --------------------------------------------------------- CAMPOS ---------------------------------------------------------
         */

        for (String field : fields) {

            score += scoreIndicator(field, 6);
        }

        /*
         * --------------------------------------------------------- GETTERS ---------------------------------------------------------
         */

        for (String getter : getters) {

            score += scoreIndicator(getter, 7);
        }

        /*
         * --------------------------------------------------------- SETTERS ---------------------------------------------------------
         */

        for (String setter : setters) {

            score += scoreIndicator(setter, 4);
        }

        /*
         * --------------------------------------------------------- MÉTODOS ---------------------------------------------------------
         */

        for (String method : methods) {

            score += scoreIndicator(method, 8);
        }

        /*
         * --------------------------------------------------------- REFERENCIAS ---------------------------------------------------------
         */

        for (String reference : references) {

            score += scoreIndicator(reference, 5);
        }

        /*
         * --------------------------------------------------------- Refuerzo por combinación de evidencias.
         *
         * Una clase que tenga varias señales diferentes es mucho más interesante que una que solamente tenga una palabra. ---------------------------------------------------------
         */

        int categories = 0;

        if (!fields.isEmpty()) {
            categories++;
        }

        if (!getters.isEmpty()) {
            categories++;
        }

        if (!setters.isEmpty()) {
            categories++;
        }

        if (!methods.isEmpty()) {
            categories++;
        }

        if (!references.isEmpty()) {
            categories++;
        }

        if (categories >= 2) {
            score += 5;
        }

        if (categories >= 3) {
            score += 8;
        }

        if (categories >= 4) {
            score += 10;
        }

        /*
         * Evitar puntuaciones absurdamente grandes.
         */

        return Math.min(score, 1000);
    }

    // =========================================================
    // PUNTUAR INDICADOR
    // =========================================================

    private int scoreIndicator(String value, int baseScore) {

        if (value == null) {
            return 0;
        }

        String text = value.toLowerCase(Locale.ROOT);

        int score = 0;

        /*
         * --------------------------------------------------------- INDICADORES MUY FUERTES ---------------------------------------------------------
         */

        if (containsAny(text, "isvip", "ispremium", "vipstatus", "premiumstatus", "vipuser",
                "premiumuser", "premiumaccess", "vipaccess", "issubscribed", "subscriptionstatus",
                "entitlement")) {

            score += baseScore + 12;

        } else if (containsAny(text, "vip", "premium", "subscription", "subscribed",
                "membership")) {

            score += baseScore + 7;

        } else if (containsAny(text, "purchase", "purchased", "billing", "productdetails", "sku",
                "inapp")) {

            score += baseScore + 3;

        } else if (containsAny(text, "trial", "renew", "expiration", "expiry", "unlock")) {

            score += baseScore + 2;

        } else {

            /*
             * Si llegó aquí significa que el indicador general detectó algo, pero es una señal más débil.
             */

            score += baseScore;
        }

        /*
         * --------------------------------------------------------- TIPOS BOOLEANOS
         *
         * Por ejemplo:
         *
         * isVip:Z isPremium:Z ---------------------------------------------------------
         */

        if (text.contains(":z") || text.endsWith(")z")) {

            if (containsAny(text, "vip", "premium", "subscribed", "member", "purchased",
                    "unlocked")) {

                score += 8;
            }
        }

        /*
         * --------------------------------------------------------- NOMBRES QUE COMIENZAN CON is/has/can ---------------------------------------------------------
         */

        if (text.contains("isvip") || text.contains("ispremium") || text.contains("haspremium")
                || text.contains("hasvip") || text.contains("canaccesspremium")) {

            score += 10;
        }

        return score;
    }

    // =========================================================
    // BUSCAR VARIOS INDICADORES
    // =========================================================

    private static boolean containsAny(String text, String... values) {

        if (text == null) {
            return false;
        }

        for (String value : values) {

            if (value != null && text.contains(value)) {
                return true;
            }
        }

        return false;
    }

    // =========================================================
    // CANDIDATO PREMIUM FUERTE
    // =========================================================

    public boolean isStrongPremiumCandidate() {

        int score = getPremiumScore();

        /*
         * Una puntuación alta por sí sola puede ser suficiente.
         */

        if (score >= 30) {
            return true;
        }

        /*
         * También consideramos especialmente fuertes los casos donde aparece un estado VIP/Premium booleano.
         */

        if (containsStrongState(fields)) {
            return true;
        }

        if (containsStrongState(getters)) {
            return true;
        }

        if (containsStrongState(methods)) {
            return true;
        }

        if (containsStrongState(references)) {
            return true;
        }

        return false;
    }

    // =========================================================
    // ESTADO FUERTE
    // =========================================================

    private boolean containsStrongState(Set<String> values) {

        for (String value : values) {

            if (value == null) {
                continue;
            }

            String text = value.toLowerCase(Locale.ROOT);

            if (text.contains("isvip") || text.contains("ispremium") || text.contains("hasvip")
                    || text.contains("haspremium") || text.contains("vipstatus")
                    || text.contains("premiumstatus")) {

                return true;
            }
        }

        return false;
    }

    // =========================================================
    // ANÁLISIS VIP PASS
    // =========================================================

    public String getPassAnalysis() {

        StringBuilder builder = new StringBuilder();

        builder.append("ANÁLISIS VIP PASS\n");

        builder.append("=================\n\n");

        builder.append("DEX: ");

        builder.append(dexName);

        builder.append("\n\n");

        builder.append("CLASE:\n");

        builder.append(className);

        builder.append("\n\n");

        builder.append("PUNTUACIÓN PREMIUM: ");

        builder.append(getPremiumScore());

        builder.append("\n\n");

        // =====================================================
        // CAMPOS
        // =====================================================

        if (!fields.isEmpty()) {

            builder.append("CAMPOS:\n");

            for (String field : fields) {

                builder.append("• ");

                builder.append(field);

                builder.append("\n");
            }

            builder.append("\n");
        }

        // =====================================================
        // GETTERS
        // =====================================================

        if (!getters.isEmpty()) {

            builder.append("GETTERS:\n");

            for (String getter : getters) {

                builder.append("• ");

                builder.append(getter);

                builder.append("\n");
            }

            builder.append("\n");
        }

        // =====================================================
        // SETTERS
        // =====================================================

        if (!setters.isEmpty()) {

            builder.append("SETTERS:\n");

            for (String setter : setters) {

                builder.append("• ");

                builder.append(setter);

                builder.append("\n");
            }

            builder.append("\n");
        }

        // =====================================================
        // MÉTODOS
        // =====================================================

        if (!methods.isEmpty()) {

            builder.append("MÉTODOS:\n");

            for (String method : methods) {

                builder.append("• ");

                builder.append(method);

                builder.append("\n");
            }

            builder.append("\n");
        }

        // =====================================================
        // REFERENCIAS
        // =====================================================

        if (!references.isEmpty()) {

            builder.append("REFERENCIAS:\n");

            for (String reference : references) {

                builder.append("• ");

                builder.append(reference);

                builder.append("\n");
            }

            builder.append("\n");
        }

        // =====================================================
        // CONCLUSIÓN
        // =====================================================

        builder.append("CONCLUSIÓN:\n");

        if (isStrongPremiumCandidate()) {

            builder.append("Este resultado presenta varias " + "señales relacionadas con estados "
                    + "Premium/VIP, suscripciones, acceso " + "o compras. Se recomienda revisar "
                    + "esta clase manualmente.");

        } else {

            builder.append("Este resultado contiene indicadores "
                    + "relacionados con Premium/VIP, pero "
                    + "la evidencia no es suficiente por sí " + "sola para determinar su función.");
        }

        return builder.toString();
    }

    // =========================================================
    // REPRESENTACIÓN PARA LA LISTA
    // =========================================================

    public String toDisplayString() {

        StringBuilder builder = new StringBuilder();

        builder.append("DEX: ");

        builder.append(dexName);

        builder.append("\n");

        builder.append("Clase: ");

        builder.append(className);

        builder.append("\n");

        builder.append("Puntuación: ");

        builder.append(getPremiumScore());

        builder.append("\n");

        if (!fields.isEmpty()) {

            builder.append("\nCampos:\n");

            for (String field : fields) {

                builder.append("  • ");

                builder.append(field);

                builder.append("\n");
            }
        }

        if (!getters.isEmpty()) {

            builder.append("\nGetters:\n");

            for (String getter : getters) {

                builder.append("  • ");

                builder.append(getter);

                builder.append("\n");
            }
        }

        if (!setters.isEmpty()) {

            builder.append("\nSetters:\n");

            for (String setter : setters) {

                builder.append("  • ");

                builder.append(setter);

                builder.append("\n");
            }
        }

        if (!methods.isEmpty()) {

            builder.append("\nMétodos:\n");

            for (String method : methods) {

                builder.append("  • ");

                builder.append(method);

                builder.append("\n");
            }
        }

        if (!references.isEmpty()) {

            builder.append("\nReferencias:\n");

            for (String reference : references) {

                builder.append("  • ");

                builder.append(reference);

                builder.append("\n");
            }
        }

        return builder.toString();
    }

    // =========================================================
    // TOSTRING
    // =========================================================

    @Override
    public String toString() {

        return toDisplayString();
    }

}