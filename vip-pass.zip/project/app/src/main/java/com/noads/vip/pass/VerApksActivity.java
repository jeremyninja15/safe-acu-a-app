package com.noads.vip.pass;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class VerApksActivity extends Activity {

    private TextView statusText;
    private LinearLayout resultsContainer;

    private final List<ApkItem> apkList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        createInterface();
        loadApksFromDownloads();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }

    private TextView text(String value, float size) {

        TextView view = new TextView(this);

        view.setText(value);
        view.setTextSize(size);

        return view;
    }

    private void createInterface() {

        LinearLayout root = new LinearLayout(this);

        root.setOrientation(LinearLayout.VERTICAL);

        root.setPadding(dp(16), dp(16), dp(16), dp(16));

        // =========================
        // TÍTULO
        // =========================

        TextView title = text("VER APKs", 28);

        title.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);

        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = text("APKs encontrados en Descargas", 15);

        root.addView(subtitle, new LinearLayout.LayoutParams(-1, -2));

        // =========================
        // ESTADO
        // =========================

        statusText = text("Cargando APKs...", 14);

        statusText.setPadding(0, dp(12), 0, dp(12));

        root.addView(statusText, new LinearLayout.LayoutParams(-1, -2));

        // =========================
        // SCROLL
        // =========================

        ScrollView scroll = new ScrollView(this);

        resultsContainer = new LinearLayout(this);

        resultsContainer.setOrientation(LinearLayout.VERTICAL);

        resultsContainer.setPadding(0, dp(8), 0, dp(30));

        scroll.addView(resultsContainer, new ScrollView.LayoutParams(-1, -2));

        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        // =========================
        // BOTÓN ATRÁS
        // =========================

        Button backButton = new Button(this);

        backButton.setText("ATRÁS");

        backButton.setOnClickListener(v -> finish());

        root.addView(backButton, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
    }

    // =========================================================
    // BUSCAR APKs
    // =========================================================

    private void loadApksFromDownloads() {

        statusText.setText("Buscando APKs en Descargas...");

        resultsContainer.removeAllViews();

        apkList.clear();

        Cursor cursor = null;

        try {

            Uri collection = MediaStore.Files.getContentUri("external");

            String[] projection = {

                    MediaStore.Files.FileColumns._ID,

                    MediaStore.Files.FileColumns.DISPLAY_NAME,

                    MediaStore.Files.FileColumns.MIME_TYPE,

                    MediaStore.Files.FileColumns.RELATIVE_PATH,

                    MediaStore.Files.FileColumns.SIZE };

            String selection = "(" + MediaStore.Files.FileColumns.DISPLAY_NAME + " LIKE ? OR "
                    + MediaStore.Files.FileColumns.MIME_TYPE + " = ?" + ")";

            String[] selectionArgs = {

                    "%.apk",

                    "application/vnd.android.package-archive" };

            String sortOrder = MediaStore.Files.FileColumns.DISPLAY_NAME + " COLLATE NOCASE ASC";

            cursor = getContentResolver().query(collection, projection, selection, selectionArgs,
                    sortOrder);

            if (cursor == null) {

                statusText.setText("No se pudo acceder a los archivos.");

                return;
            }

            int idColumn = cursor.getColumnIndex(MediaStore.Files.FileColumns._ID);

            int nameColumn = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME);

            int mimeColumn = cursor.getColumnIndex(MediaStore.Files.FileColumns.MIME_TYPE);

            int pathColumn = cursor.getColumnIndex(MediaStore.Files.FileColumns.RELATIVE_PATH);

            int sizeColumn = cursor.getColumnIndex(MediaStore.Files.FileColumns.SIZE);

            if (idColumn < 0 || nameColumn < 0) {

                statusText.setText("No se pudieron leer los datos de los APK.");

                return;
            }

            while (cursor.moveToNext()) {

                long id = cursor.getLong(idColumn);

                String name = cursor.getString(nameColumn);

                String mime = "";

                if (mimeColumn >= 0 && !cursor.isNull(mimeColumn)) {

                    mime = cursor.getString(mimeColumn);
                }

                String relativePath = "";

                if (pathColumn >= 0 && !cursor.isNull(pathColumn)) {

                    relativePath = cursor.getString(pathColumn);
                }

                long size = 0;

                if (sizeColumn >= 0 && !cursor.isNull(sizeColumn)) {

                    size = cursor.getLong(sizeColumn);
                }

                // Solo APKs dentro de Descargas
                boolean isDownload = relativePath != null
                        && relativePath.toLowerCase(Locale.ROOT).contains("download");

                if (!isDownload) {
                    continue;
                }

                // Comprobar nuevamente que sea APK
                boolean isApk = (name != null && name.toLowerCase(Locale.ROOT).endsWith(".apk"))
                        || "application/vnd.android.package-archive".equalsIgnoreCase(mime);

                if (!isApk) {
                    continue;
                }

                Uri fileUri = Uri.withAppendedPath(collection, String.valueOf(id));

                ApkItem item = new ApkItem(name, mime, relativePath, size, fileUri);

                apkList.add(item);
            }

        } catch (SecurityException e) {

            statusText.setText("Permiso insuficiente para acceder a los archivos.");

            return;

        } catch (Exception e) {

            statusText.setText("Error buscando APKs:\n" + e.getMessage());

            return;

        } finally {

            if (cursor != null) {
                cursor.close();
            }
        }

        // =====================================================
        // MOSTRAR RESULTADOS
        // =====================================================

        if (apkList.isEmpty()) {

            statusText.setText("No se encontraron APKs en Descargas.");

            TextView empty = text(
                    "No se encontraron APKs.\n\n" + "Comprueba que el archivo termine en .apk "
                            + "y esté dentro de la carpeta Descargas.",
                    14);

            empty.setPadding(dp(8), dp(12), dp(8), dp(12));

            resultsContainer.addView(empty, new LinearLayout.LayoutParams(-1, -2));

            return;
        }

        statusText.setText("Se encontraron " + apkList.size() + " APK(s)");

        for (int i = 0; i < apkList.size(); i++) {

            addApkToList(apkList.get(i), i + 1);
        }
    }

    // =========================================================
    // MOSTRAR APK
    // =========================================================

    private void addApkToList(ApkItem apk, int number) {

        LinearLayout card = new LinearLayout(this);

        card.setOrientation(LinearLayout.VERTICAL);

        card.setPadding(dp(12), dp(12), dp(12), dp(12));

        TextView item = text("━━━━━━━━━━━━━━━━━━\n" + "APK #" + number + "\n\n" + "📦 " + apk.name
                + "\n\n" + "Ubicación:\n" + apk.relativePath + "\n\n" + "Tamaño: "
                + formatSize(apk.size), 14);

        item.setTextIsSelectable(true);

        card.addView(item, new LinearLayout.LayoutParams(-1, -2));

        // =========================
        // USAR APK
        // =========================

        Button selectButton = new Button(this);

        selectButton.setText("USAR ESTE APK");

        selectButton.setOnClickListener(v -> selectApk(apk));

        card.addView(selectButton, new LinearLayout.LayoutParams(-1, -2));

        resultsContainer.addView(card, new LinearLayout.LayoutParams(-1, -2));
    }

    // =========================================================
    // SELECCIONAR APK
    // =========================================================

    private void selectApk(ApkItem apk) {

        try {

            Intent resultIntent = new Intent();

            resultIntent.setData(apk.uri);

            resultIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

            setResult(RESULT_OK, resultIntent);

            Toast.makeText(this, "✓ APK seleccionado: " + apk.name, Toast.LENGTH_SHORT).show();

            finish();

        } catch (Exception e) {

            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    // =========================================================
    // FORMATEAR TAMAÑO
    // =========================================================

    private String formatSize(long bytes) {

        if (bytes <= 0) {
            return "desconocido";
        }

        if (bytes < 1024) {
            return bytes + " B";
        }

        if (bytes < 1024L * 1024L) {

            return String.format(Locale.getDefault(), "%.1f KB", bytes / 1024.0);
        }

        if (bytes < 1024L * 1024L * 1024L) {

            return String.format(Locale.getDefault(), "%.1f MB", bytes / (1024.0 * 1024.0));
        }

        return String.format(Locale.getDefault(), "%.1f GB", bytes / (1024.0 * 1024.0 * 1024.0));
    }

    // =========================================================
    // MODELO APK
    // =========================================================

    private static class ApkItem {

        final String name;
        final String mime;
        final String relativePath;
        final long size;
        final Uri uri;

        ApkItem(String name, String mime, String relativePath, long size, Uri uri) {

            this.name = name;
            this.mime = mime;
            this.relativePath = relativePath;
            this.size = size;
            this.uri = uri;
        }
    }
}