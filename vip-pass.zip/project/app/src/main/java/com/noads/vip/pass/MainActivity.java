package com.noads.vip.pass;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;

public class MainActivity extends Activity {

    private static final int PICK_APK = 1001;
    private static final int PICK_DOWNLOAD_APK = 1002;

    private Uri apkUri;

    private TextView apkText;
    private TextView statusText;
    private TextView resultCountText;

    private LinearLayout resultsContainer;

    private Button analyzeButton;
    private Button editButton;
    private Button copyAllButton;
    private Button clearButton;

    private final ArrayList<DexSearchResult> results =
            new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        createInterface();
    }

    private int dp(float value) {

        return (int) (
                value *
                getResources()
                        .getDisplayMetrics()
                        .density
        );
    }

    private TextView text(
            String value,
            float size) {

        TextView view =
                new TextView(this);

        view.setText(value);
        view.setTextSize(size);

        return view;
    }

    private void createInterface() {

        LinearLayout root =
                new LinearLayout(this);

        root.setOrientation(
                LinearLayout.VERTICAL
        );

        root.setPadding(
                dp(16),
                dp(16),
                dp(16),
                dp(16)
        );

        // =====================================================
        // TÍTULO
        // =====================================================

        TextView title =
                text("VIP PASS", 28);

        title.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD
        );

        root.addView(
                title,
                new LinearLayout.LayoutParams(
                        -1,
                        -2
                )
        );

        TextView subtitle =
                text(
                        "Analizador y editor de APK / DEX",
                        15
                );

        root.addView(
                subtitle,
                marginParams(
                        -1,
                        -2,
                        0,
                        2,
                        0,
                        12
                )
        );

        // =====================================================
        // SELECCIONAR APK
        // =====================================================

        Button selectButton =
                new Button(this);

        selectButton.setText(
                "📦 SELECCIONAR APK"
        );

        root.addView(
                selectButton,
                marginParams(
                        -1,
                        -2,
                        0,
                        0,
                        0,
                        8
                )
        );

        selectButton.setOnClickListener(
                v -> selectApk()
        );

        // =====================================================
        // APKs DE DESCARGAS
        // =====================================================

        Button downloadsButton =
                new Button(this);

        downloadsButton.setText(
                "📂 VER APKs EN DESCARGAS"
        );

        root.addView(
                downloadsButton,
                marginParams(
                        -1,
                        -2,
                        0,
                        0,
                        0,
                        8
                )
        );

        downloadsButton.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            MainActivity.this,
                            VerApksActivity.class
                    );

            startActivityForResult(
                    intent,
                    PICK_DOWNLOAD_APK
            );
        });

        // =====================================================
        // APK SELECCIONADO
        // =====================================================

        apkText =
                text(
                        "APK seleccionado: ninguno",
                        13
                );

        apkText.setTextIsSelectable(true);

        root.addView(
                apkText,
                marginParams(
                        -1,
                        -2,
                        0,
                        4,
                        0,
                        8
                )
        );

        // =====================================================
        // DESCRIPCIÓN
        // =====================================================

        TextView automaticText =
                text(
                        "🤖 ANÁLISIS AUTOMÁTICO\n\n"
                        + "El analizador buscará indicadores "
                        + "relacionados con estados, métodos, "
                        + "campos, suscripciones, compras y "
                        + "otras referencias relevantes.\n\n"
                        + "También puedes abrir el APK en el "
                        + "editor para inspeccionarlo manualmente.",
                        13
                );

        automaticText.setPadding(
                dp(10),
                dp(10),
                dp(10),
                dp(10)
        );

        root.addView(
                automaticText,
                marginParams(
                        -1,
                        -2,
                        0,
                        0,
                        0,
                        8
                )
        );

        // =====================================================
        // ANALIZAR
        // =====================================================

        analyzeButton =
                new Button(this);

        analyzeButton.setText(
                "🔍 ANALIZAR AUTOMÁTICAMENTE"
        );

        analyzeButton.setEnabled(false);

        root.addView(
                analyzeButton,
                marginParams(
                        -1,
                        -2,
                        0,
                        0,
                        0,
                        6
                )
        );

        analyzeButton.setOnClickListener(
                v -> analyze()
        );

        // =====================================================
        // EDITAR APK
        // =====================================================

        editButton =
                new Button(this);

        editButton.setText(
                "🛠️ EDITAR APK MANUALMENTE"
        );

        editButton.setEnabled(false);

        root.addView(
                editButton,
                marginParams(
                        -1,
                        -2,
                        0,
                        0,
                        0,
                        8
                )
        );

        editButton.setOnClickListener(
                v -> openEditor()
        );

        // =====================================================
        // HERRAMIENTAS
        // =====================================================

        LinearLayout tools =
                new LinearLayout(this);

        tools.setOrientation(
                LinearLayout.HORIZONTAL
        );

        copyAllButton =
                new Button(this);

        copyAllButton.setText(
                "COPIAR TODO"
        );

        copyAllButton.setEnabled(false);

        tools.addView(
                copyAllButton,
                new LinearLayout.LayoutParams(
                        0,
                        -2,
                        1
                )
        );

        copyAllButton.setOnClickListener(
                v -> copyAllResults()
        );

        clearButton =
                new Button(this);

        clearButton.setText(
                "LIMPIAR"
        );

        clearButton.setEnabled(false);

        tools.addView(
                clearButton,
                new LinearLayout.LayoutParams(
                        0,
                        -2,
                        1
                )
        );

        clearButton.setOnClickListener(
                v -> clearResults()
        );

        root.addView(
                tools,
                marginParams(
                        -1,
                        -2,
                        0,
                        0,
                        0,
                        6
                )
        );

        // =====================================================
        // ESTADO
        // =====================================================

        statusText =
                text(
                        "Selecciona un APK para comenzar.",
                        14
                );

        statusText.setPadding(
                0,
                dp(8),
                0,
                dp(8)
        );

        root.addView(statusText);

        // =====================================================
        // CONTADOR
        // =====================================================

        resultCountText =
                text(
                        "Resultados: 0",
                        16
                );

        resultCountText.setTypeface(
                Typeface.DEFAULT,
                Typeface.BOLD
        );

        root.addView(
                resultCountText,
                marginParams(
                        -1,
                        -2,
                        0,
                        0,
                        0,
                        4
                )
        );

        // =====================================================
        // RESULTADOS
        // =====================================================

        ScrollView scroll =
                new ScrollView(this);

        resultsContainer =
                new LinearLayout(this);

        resultsContainer.setOrientation(
                LinearLayout.VERTICAL
        );

        resultsContainer.setPadding(
                0,
                dp(8),
                0,
                dp(30)
        );

        scroll.addView(
                resultsContainer
        );

        root.addView(
                scroll,
                new LinearLayout.LayoutParams(
                        -1,
                        0,
                        1
                )
        );

        setContentView(root);
    }

    // =========================================================
    // ABRIR EDITOR
    // =========================================================

    private void openEditor() {

        if (apkUri == null) {

            Toast.makeText(
                    this,
                    "❌ Primero selecciona un APK.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        try {

            Intent intent =
                    new Intent(
                            MainActivity.this,
                            ApkEditorActivity.class
                    );

            intent.setData(apkUri);

            intent.addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
            );

            startActivity(intent);

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "❌ No se pudo abrir el editor: "
                            + e.getMessage(),
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private LinearLayout.LayoutParams marginParams(
            int width,
            int height,
            int left,
            int top,
            int right,
            int bottom) {

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        width,
                        height
                );

        params.setMargins(
                dp(left),
                dp(top),
                dp(right),
                dp(bottom)
        );

        return params;
    }

    private void selectApk() {

        Intent intent =
                new Intent(
                        Intent.ACTION_OPEN_DOCUMENT
                );

        intent.addCategory(
                Intent.CATEGORY_OPENABLE
        );

        intent.setType(
                "application/vnd.android.package-archive"
        );

        intent.addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION
        );

        intent.addFlags(
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        );

        startActivityForResult(
                intent,
                PICK_APK
        );
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data) {

        super.onActivityResult(
                requestCode,
                resultCode,
                data
        );

        if (
                resultCode != RESULT_OK
                || data == null
        ) {
            return;
        }

        if (
                requestCode == PICK_APK
        ) {

            Uri selectedUri =
                    data.getData();

            if (selectedUri == null) {
                return;
            }

            apkUri = selectedUri;

            try {

                getContentResolver()
                        .takePersistableUriPermission(
                                apkUri,
                                Intent.FLAG_GRANT_READ_URI_PERMISSION
                        );

            } catch (Exception ignored) {
            }

            apkText.setText(
                    "APK seleccionado:\n"
                            + getDisplayName(apkUri)
            );

            statusText.setText(
                    "✓ APK seleccionado correctamente."
            );

            analyzeButton.setEnabled(true);
            editButton.setEnabled(true);

            return;
        }

        if (
                requestCode ==
                PICK_DOWNLOAD_APK
        ) {

            Uri selectedUri =
                    data.getData();

            if (selectedUri == null) {

                statusText.setText(
                        "❌ No se recibió el APK."
                );

                return;
            }

            apkUri = selectedUri;

            try {

                getContentResolver()
                        .takePersistableUriPermission(
                                apkUri,
                                Intent.FLAG_GRANT_READ_URI_PERMISSION
                        );

            } catch (Exception ignored) {
            }

            apkText.setText(
                    "APK seleccionado:\n"
                            + getDisplayName(apkUri)
            );

            statusText.setText(
                    "✓ APK de Descargas seleccionado."
            );

            analyzeButton.setEnabled(true);
            editButton.setEnabled(true);
        }
    }

    private String getDisplayName(Uri uri) {

        if (uri == null) {
            return "desconocido";
        }

        String name = null;

        try {

            android.database.Cursor cursor =
                    getContentResolver().query(
                            uri,
                            new String[]{
                                    android.provider.OpenableColumns.DISPLAY_NAME
                            },
                            null,
                            null,
                            null
                    );

            if (cursor != null) {

                if (cursor.moveToFirst()) {

                    int index =
                            cursor.getColumnIndex(
                                    android.provider.OpenableColumns.DISPLAY_NAME
                            );

                    if (index >= 0) {

                        name =
                                cursor.getString(index);
                    }
                }

                cursor.close();
            }

        } catch (Exception ignored) {
        }

        if (
                name == null
                || name.trim().isEmpty()
        ) {

            name = uri.toString();
        }

        return name;
    }

    // =========================================================
    // ANALIZADOR
    // =========================================================

    private void analyze() {

        if (apkUri == null) {

            statusText.setText(
                    "❌ Primero selecciona un APK."
            );

            return;
        }

        results.clear();

        resultsContainer.removeAllViews();

        resultCountText.setText(
                "Resultados: 0"
        );

        copyAllButton.setEnabled(false);
        clearButton.setEnabled(false);
        analyzeButton.setEnabled(false);

        statusText.setText(
                "🤖 Analizando automáticamente..."
        );

        DexAnalyzer.analyze(
                this,
                apkUri,
                new DexAnalyzer.Callback() {

                    private int count = 0;

                    @Override
                    public void onDexFound(
                            String dexName) {

                        runOnUiThread(() ->
                                statusText.setText(
                                        "🔍 Analizando "
                                                + dexName
                                                + "..."
                                )
                        );
                    }

                    @Override
                    public void onResult(
                            DexSearchResult result) {

                        if (result == null) {
                            return;
                        }

                        int number = 0;

                        synchronized (results) {

                            results.add(result);

                            count++;

                            number = count;
                        }

                        final int finalNumber = number;

                        runOnUiThread(() -> {

                            addResult(
                                    result,
                                    finalNumber
                            );

                            resultCountText.setText(
                                    "Resultados: "
                                            + results.size()
                            );

                            copyAllButton
                                    .setEnabled(true);

                            clearButton
                                    .setEnabled(true);
                        });
                    }

                    @Override
                    public void onFinished(
                            int total) {

                        runOnUiThread(() -> {

                            analyzeButton
                                    .setEnabled(true);

                            editButton
                                    .setEnabled(
                                            apkUri != null
                                    );

                            resultCountText.setText(
                                    "Resultados: "
                                            + results.size()
                            );

                            statusText.setText(
                                    "✓ Análisis terminado. "
                                            + "Se encontraron "
                                            + results.size()
                                            + " puntos relacionados."
                            );

                            if (
                                    !results.isEmpty()
                            ) {

                                copyAllButton
                                        .setEnabled(true);

                                clearButton
                                        .setEnabled(true);
                            }
                        });
                    }

                    @Override
                    public void onError(
                            Exception e) {

                        runOnUiThread(() -> {

                            analyzeButton
                                    .setEnabled(true);

                            editButton
                                    .setEnabled(
                                            apkUri != null
                                    );

                            String message =
                                    e.getMessage();

                            if (
                                    message == null
                                    || message.trim()
                                            .isEmpty()
                            ) {

                                message =
                                        e.toString();
                            }

                            final String finalMessage = message;

                            statusText.setText(
                                    "❌ Error: "
                                            + finalMessage
                            );
                        });
                    }
                }
        );
    }

    private void addResult(
            DexSearchResult result,
            int number) {

        LinearLayout card =
                new LinearLayout(this);

        card.setOrientation(
                LinearLayout.VERTICAL
        );

        card.setPadding(
                dp(12),
                dp(12),
                dp(12),
                dp(12)
        );

        TextView item =
                new TextView(this);

        item.setText(
                "━━━━━━━━━━━━━━━━━━\n"
                        + "#"
                        + number
                        + "\n\n"
                        + result.toDisplayString()
        );

        item.setTextSize(13);

        item.setTextIsSelectable(true);

        card.addView(
                item,
                new LinearLayout.LayoutParams(
                        -1,
                        -2
                )
        );

        if (
                result.isStrongPremiumCandidate()
        ) {

            Button detailsButton =
                    new Button(this);

            detailsButton.setText(
                    "🔎 VER DETALLES"
            );

            detailsButton.setOnClickListener(
                    v -> showPassAnalysis(result)
            );

            card.addView(
                    detailsButton,
                    marginParams(
                            -1,
                            -2,
                            0,
                            8,
                            0,
                            0
                    )
            );
        }

        resultsContainer.addView(
                card,
                new LinearLayout.LayoutParams(
                        -1,
                        -2
                )
        );
    }

    private void showPassAnalysis(
            DexSearchResult result) {

        if (result == null) {
            return;
        }

        final String analysisText =
                result.getPassAnalysis();

        try {

            new AlertDialog.Builder(this)
                    .setTitle("ANÁLISIS")
                    .setMessage(analysisText)
                    .setPositiveButton(
                            "COPIAR",
                            (dialog, which) ->
                                    copyTextSafely(
                                            "VIP PASS",
                                            analysisText
                                    )
                    )
                    .setNegativeButton(
                            "CERRAR",
                            null
                    )
                    .show();

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "Error mostrando análisis: "
                            + e.getMessage(),
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private void copyTextSafely(
            String label,
            String text) {

        if (text == null) {
            text = "";
        }

        final int MAX_CLIPBOARD_SIZE =
                100000;

        if (
                text.length()
                        > MAX_CLIPBOARD_SIZE
        ) {

            text =
                    text.substring(
                            0,
                            MAX_CLIPBOARD_SIZE
                    )
                    + "\n\n[CONTENIDO RECORTADO]";
        }

        try {

            ClipboardManager clipboard =
                    (ClipboardManager)
                            getSystemService(
                                    Context.CLIPBOARD_SERVICE
                            );

            if (clipboard == null) {

                Toast.makeText(
                        this,
                        "Portapapeles no disponible",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            ClipData clip =
                    ClipData.newPlainText(
                            label,
                            text
                    );

            clipboard.setPrimaryClip(clip);

            Toast.makeText(
                    this,
                    "✓ Copiado correctamente",
                    Toast.LENGTH_SHORT
            ).show();

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "❌ No se pudo copiar: "
                            + e.getClass()
                                    .getSimpleName(),
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private String buildAllResults() {

        StringBuilder builder =
                new StringBuilder();

        builder.append(
                "VIP PASS - RESULTADOS\n"
        );

        builder.append(
                "====================\n\n"
        );

        builder.append(
                "Modo: ANÁLISIS AUTOMÁTICO\n"
        );

        builder.append(
                "Resultados: "
        );

        builder.append(
                results.size()
        );

        builder.append("\n\n");

        for (
                int i = 0;
                i < results.size();
                i++
        ) {

            DexSearchResult result =
                    results.get(i);

            builder.append(
                    "━━━━━━━━━━━━━━━━━━\n"
            );

            builder.append(
                    "#"
                            + (i + 1)
            );

            builder.append("\n\n");

            builder.append(
                    result.toDisplayString()
            );

            builder.append("\n\n");
        }

        return builder.toString();
    }

    private void copyAllResults() {

        if (
                results == null
                || results.isEmpty()
        ) {

            Toast.makeText(
                    this,
                    "No hay resultados para copiar",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        String all;

        try {

            all =
                    buildAllResults();

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "Error preparando resultados",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        final int MAX_COPY_SIZE =
                200000;

        if (
                all.length()
                        > MAX_COPY_SIZE
        ) {

            StringBuilder limited =
                    new StringBuilder();

            limited.append(
                    "VIP PASS - RESUMEN\n\n"
            );

            limited.append(
                    "Resultados encontrados: "
            );

            limited.append(
                    results.size()
            );

            limited.append("\n\n");

            for (
                    int i = 0;
                    i < results.size();
                    i++
            ) {

                DexSearchResult result =
                        results.get(i);

                String text;

                try {

                    text =
                            result.toDisplayString();

                } catch (Exception e) {

                    continue;
                }

                if (text == null) {
                    continue;
                }

                String block =
                        "━━━━━━━━━━━━━━━━━━\n"
                        + "#"
                        + (i + 1)
                        + "\n\n"
                        + text
                        + "\n\n";

                if (
                        limited.length()
                                + block.length()
                                > MAX_COPY_SIZE
                ) {

                    limited.append(
                            "[RESTANTES OMITIDOS]\n"
                    );

                    break;
                }

                limited.append(block);
            }

            all =
                    limited.toString();

            Toast.makeText(
                    this,
                    "Resultado grande: se copió un resumen",
                    Toast.LENGTH_LONG
            ).show();
        }

        copyTextSafely(
                "VIP PASS resultados",
                all
        );
    }

    private void clearResults() {

        try {

            results.clear();

            if (
                    resultsContainer != null
            ) {

                resultsContainer
                        .removeAllViews();
            }

            if (
                    resultCountText != null
            ) {

                resultCountText.setText(
                        "Resultados: 0"
                );
            }

            if (
                    copyAllButton != null
            ) {

                copyAllButton
                        .setEnabled(false);
            }

            if (
                    clearButton != null
            ) {

                clearButton
                        .setEnabled(false);
            }

            if (
                    statusText != null
            ) {

                statusText.setText(
                        "Resultados limpiados."
                );
            }

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "Error limpiando resultados",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    private FileUriResult createFileUri(
            String path) {

        try {

            File file =
                    new File(path);

            if (
                    !file.exists()
                    || !file.isFile()
            ) {

                return null;
            }

            File cacheFile =
                    new File(
                            getCacheDir(),
                            "downloads_selected.apk"
                    );

            java.io.FileInputStream input =
                    new java.io.FileInputStream(file);

            java.io.FileOutputStream output =
                    new java.io.FileOutputStream(
                            cacheFile
                    );

            byte[] buffer =
                    new byte[8192];

            int read;

            while (
                    (read =
                            input.read(buffer))
                            != -1
            ) {

                output.write(
                        buffer,
                        0,
                        read
                );
            }

            input.close();
            output.close();

            Uri uri =
                    Uri.fromFile(
                            cacheFile
                    );

            return new FileUriResult(
                    uri,
                    file.getName()
            );

        } catch (Exception e) {

            return null;
        }
    }

    private static class FileUriResult {

        final Uri uri;
        final String displayName;

        FileUriResult(
                Uri uri,
                String displayName) {

            this.uri = uri;
            this.displayName =
                    displayName;
        }
    }
}