package com.noads.vip.pass;

public class ManifestEditor {
}
