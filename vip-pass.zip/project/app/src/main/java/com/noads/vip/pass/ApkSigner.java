package com.noads.vip.pass;

import java.io.File;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;

public class ApkSigner {

    /**
     * Firma un APK usando un keystore JKS o PKCS12.
     *
     * @param unsignedApk APK sin firmar
     * @param signedApk APK de salida firmado
     * @param keystoreFile archivo .jks, .p12 o .pfx
     * @param keystorePassword contraseña del keystore
     * @param alias alias de la clave
     * @param keyPassword contraseña de la clave
     */
    public File sign(
            File unsignedApk,
            File signedApk,
            File keystoreFile,
            String keystorePassword,
            String alias,
            String keyPassword
    ) throws Exception {

        // ---------------------------------------------------------
        // VALIDACIONES
        // ---------------------------------------------------------

        if (unsignedApk == null || !unsignedApk.exists()) {
            throw new Exception(
                    "APK sin firma no encontrado:\n"
                            + (unsignedApk != null
                            ? unsignedApk.getAbsolutePath()
                            : "null")
            );
        }

        if (unsignedApk.length() == 0) {
            throw new Exception("El APK sin firma está vacío.");
        }

        if (keystoreFile == null || !keystoreFile.exists()) {
            throw new Exception(
                    "Keystore no encontrado:\n"
                            + (keystoreFile != null
                            ? keystoreFile.getAbsolutePath()
                            : "null")
            );
        }

        if (keystorePassword == null) {
            throw new Exception("La contraseña del keystore es null.");
        }

        if (alias == null || alias.trim().isEmpty()) {
            throw new Exception("El alias del keystore está vacío.");
        }

        if (keyPassword == null) {
            keyPassword = keystorePassword;
        }

        if (signedApk == null) {
            throw new Exception("APK de salida inválido.");
        }

        // ---------------------------------------------------------
        // CREAR DIRECTORIO DE SALIDA
        // ---------------------------------------------------------

        File parent = signedApk.getParentFile();

        if (parent != null && !parent.exists()) {
            if (!parent.mkdirs() && !parent.exists()) {
                throw new Exception(
                        "No se pudo crear el directorio:\n"
                                + parent.getAbsolutePath()
                );
            }
        }

        // ---------------------------------------------------------
        // ELIMINAR APK ANTERIOR
        // ---------------------------------------------------------

        if (signedApk.exists()) {

            if (!signedApk.delete()) {
                throw new Exception(
                        "No se pudo eliminar el APK firmado anterior:\n"
                                + signedApk.getAbsolutePath()
                );
            }
        }

        // ---------------------------------------------------------
        // CARGAR KEYSTORE
        // ---------------------------------------------------------

        KeyStore keyStore = loadKeyStore(
                keystoreFile,
                keystorePassword
        );

        // ---------------------------------------------------------
        // COMPROBAR ALIAS
        // ---------------------------------------------------------

        if (!keyStore.containsAlias(alias)) {
            throw new Exception(
                    "No existe el alias '" + alias
                            + "' en el keystore."
            );
        }

        // ---------------------------------------------------------
        // OBTENER CLAVE PRIVADA
        // ---------------------------------------------------------

        KeyStore.Entry entry;

        try {

            entry = keyStore.getEntry(
                    alias,
                    new KeyStore.PasswordProtection(
                            keyPassword.toCharArray()
                    )
            );

        } catch (Exception e) {

            throw new Exception(
                    "No se pudo obtener la clave privada.\n"
                            + "Revisa el alias y la contraseña de la clave.\n\n"
                            + e.getMessage(),
                    e
            );
        }

        if (!(entry instanceof KeyStore.PrivateKeyEntry)) {
            throw new Exception(
                    "El alias '" + alias
                            + "' no contiene una clave privada."
            );
        }

        KeyStore.PrivateKeyEntry privateKeyEntry =
                (KeyStore.PrivateKeyEntry) entry;

        PrivateKey privateKey =
                privateKeyEntry.getPrivateKey();

        if (privateKey == null) {
            throw new Exception(
                    "No se pudo obtener la clave privada."
            );
        }

        // ---------------------------------------------------------
        // OBTENER CERTIFICADO
        // ---------------------------------------------------------

        java.security.cert.Certificate certificate =
                privateKeyEntry.getCertificate();

        if (certificate == null) {
            throw new Exception(
                    "No se pudo obtener el certificado."
            );
        }

        if (!(certificate instanceof X509Certificate)) {
            throw new Exception(
                    "El certificado no es X509."
            );
        }

        X509Certificate x509Certificate =
                (X509Certificate) certificate;

        // ---------------------------------------------------------
        // CREAR LISTA DE CERTIFICADOS
        // ---------------------------------------------------------

        List<X509Certificate> certificates =
                new ArrayList<X509Certificate>();

        certificates.add(x509Certificate);

        // ---------------------------------------------------------
        // CREAR SIGNER CONFIG
        //
        // IMPORTANTE:
        // No usamos "import com.android.apksig.ApkSigner"
        // porque nuestra clase también se llama ApkSigner.
        // ---------------------------------------------------------

        com.android.apksig.ApkSigner.SignerConfig signerConfig =
                new com.android.apksig.ApkSigner.SignerConfig.Builder(
                        alias,
                        privateKey,
                        certificates
                ).build();

        // ---------------------------------------------------------
        // LISTA DE SIGNERS
        // ---------------------------------------------------------

        List<com.android.apksig.ApkSigner.SignerConfig> signers =
                new ArrayList<com.android.apksig.ApkSigner.SignerConfig>();

        signers.add(signerConfig);

        // ---------------------------------------------------------
        // CREAR APK SIGNER
        // ---------------------------------------------------------

        com.android.apksig.ApkSigner apkSigner =
                new com.android.apksig.ApkSigner.Builder(signers)
                        .setInputApk(unsignedApk)
                        .setOutputApk(signedApk)
                        .setV1SigningEnabled(true)
                        .setV2SigningEnabled(true)
                        .setV3SigningEnabled(true)
                        .build();

        // ---------------------------------------------------------
        // FIRMAR APK
        // ---------------------------------------------------------

        apkSigner.sign();

        // ---------------------------------------------------------
        // COMPROBAR RESULTADO
        // ---------------------------------------------------------

        if (!signedApk.exists()) {
            throw new Exception(
                    "ApkSigner terminó pero no creó el APK."
            );
        }

        if (signedApk.length() == 0) {
            throw new Exception(
                    "ApkSigner creó un APK vacío."
            );
        }

        return signedApk;
    }

    // =============================================================
    // CARGAR KEYSTORE
    // =============================================================

    private KeyStore loadKeyStore(
            File file,
            String password
    ) throws Exception {

        String type = detectKeyStoreType(file);

        KeyStore keyStore =
                KeyStore.getInstance(type);

        FileInputStream input =
                new FileInputStream(file);

        try {

            keyStore.load(
                    input,
                    password.toCharArray()
            );

        } finally {

            input.close();
        }

        return keyStore;
    }

    // =============================================================
    // DETECTAR TIPO DE KEYSTORE
    // =============================================================

    private String detectKeyStoreType(File file) {

        String name =
                file.getName().toLowerCase();

        if (name.endsWith(".p12")
                || name.endsWith(".pfx")) {

            return "PKCS12";
        }

        if (name.endsWith(".jks")) {

            return "JKS";
        }

        // Por defecto usamos PKCS12.
        return "PKCS12";
    }
}