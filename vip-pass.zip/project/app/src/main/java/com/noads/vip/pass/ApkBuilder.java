package com.noads.vip.pass;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.zip.CRC32;

public class ApkBuilder {

    private static final int BUFFER_SIZE = 8192;

    private static final int LOCAL_FILE_HEADER = 0x04034b50;
    private static final int CENTRAL_FILE_HEADER = 0x02014b50;
    private static final int END_OF_CENTRAL_DIRECTORY = 0x06054b50;

    /*
     * Máximo estándar para buscar EOCD:
     *
     * 22 bytes mínimos de EOCD
     * + 65535 bytes de comentario
     */
    private static final int MAX_EOCD_SEARCH = 65557;

    // =========================================================
    // INFORMACIÓN DE UNA ENTRADA ZIP
    // =========================================================

    private static class ZipEntryInfo {

        String name;

        byte[] nameBytes;
        byte[] extra;
        byte[] comment;

        int versionMadeBy;
        int versionNeeded;
        int flags;
        int method;

        int modTime;
        int modDate;

        long crc;
        long compressedSize;
        long uncompressedSize;

        long localHeaderOffset;

        int diskNumberStart;
        int internalAttributes;
        long externalAttributes;

        boolean replaced;
        boolean removed;
    }

    // =========================================================
    // INFORMACIÓN ZIP
    // =========================================================

    private static class ZipInfo {

        final List<ZipEntryInfo> entries =
                new ArrayList<ZipEntryInfo>();

        long centralDirectoryOffset;
        long centralDirectorySize;

        byte[] archiveComment;
    }

    // =========================================================
    // RECONSTRUIR APK
    // =========================================================

    public File rebuild(
            File originalApk,
            File newDex,
            String dexName,
            File outputApk
    ) throws Exception {

        validateArguments(
                originalApk,
                newDex,
                dexName,
                outputApk
        );

        dexName = dexName.trim();

        File parent =
                outputApk.getParentFile();

        if (parent != null
                && !parent.exists()) {

            if (!parent.mkdirs()
                    && !parent.exists()) {

                throw new IOException(
                        "No se pudo crear el directorio:\n"
                                + parent.getAbsolutePath()
                );
            }
        }

        if (outputApk.exists()) {

            if (!outputApk.delete()) {

                throw new IOException(
                        "No se pudo eliminar el APK anterior."
                );
            }
        }

        RandomAccessFile input =
                null;

        FileOutputStream output =
                null;

        try {

            input =
                    new RandomAccessFile(
                            originalApk,
                            "r"
                    );

            // -------------------------------------------------
            // LEER DIRECTORIO CENTRAL ORIGINAL
            // -------------------------------------------------

            ZipInfo zipInfo =
                    readZipInfo(
                            input
                    );

            ZipEntryInfo target =
                    null;

            for (ZipEntryInfo entry :
                    zipInfo.entries) {

                if (dexName.equals(
                        entry.name)) {

                    target = entry;
                    break;
                }
            }

            if (target == null) {

                throw new IOException(
                        "No se encontró el DEX:\n"
                                + dexName
                );
            }

            // -------------------------------------------------
            // INFORMACIÓN DEL NUEVO DEX
            // -------------------------------------------------

            long newDexSize =
                    newDex.length();

            if (newDexSize
                    > 0xffffffffL) {

                throw new IOException(
                        "El DEX supera el límite ZIP32."
                );
            }

            long newDexCrc =
                    calculateCrc32(
                            newDex
                    );

            /*
             * =================================================
             * PRIMERA PASADA
             *
             * Calculamos exactamente cuánto ocupará cada
             * entrada en el nuevo APK.
             *
             * NO escribimos todavía.
             * =================================================
             */

            long[] newOffsets =
                    new long[
                            zipInfo.entries.size()
                    ];

            long outputPosition = 0;

            for (int i = 0;
                 i < zipInfo.entries.size();
                 i++) {

                ZipEntryInfo entry =
                        zipInfo.entries.get(i);

                /*
                 * Las firmas V1 antiguas no se conservan,
                 * porque después de modificar el APK dejan de
                 * ser válidas y ApkSigner deberá generar la firma.
                 */
                if (isSignatureFile(
                        entry.name)) {

                    entry.removed = true;

                    newOffsets[i] =
                            -1;

                    continue;
                }

                newOffsets[i] =
                        outputPosition;

                if (entry == target) {

                    /*
                     * NUEVO DEX
                     *
                     * Se escribe STORED:
                     *
                     * - no se comprime
                     * - no se vuelve a descomprimir
                     * - los datos son exactamente los del newDex
                     */

                    int nameLength =
                            entry.nameBytes.length;

                    int extraLength =
                            getTargetExtraLength(
                                    entry
                            );

                    long localSize =
                            30L
                                    + nameLength
                                    + extraLength
                                    + newDexSize;

                    outputPosition +=
                            localSize;

                    entry.replaced = true;

                } else {

                    /*
                     * ENTRADA ORIGINAL
                     *
                     * Copiamos:
                     *
                     * local header
                     * + nombre
                     * + extra
                     * + datos comprimidos
                     * + data descriptor si existe
                     *
                     * SIN recomprimir.
                     */

                    long localSize =
                            getLocalEntryTotalSize(
                                    input,
                                    entry
                            );

                    outputPosition +=
                            localSize;
                }
            }

            long centralDirectoryOffset =
                    outputPosition;

            // -------------------------------------------------
            // CALCULAR TAMAÑO DEL DIRECTORIO CENTRAL
            // -------------------------------------------------

            long centralDirectorySize =
                    0;

            int entryCount =
                    0;

            for (ZipEntryInfo entry :
                    zipInfo.entries) {

                if (entry.removed) {
                    continue;
                }

                centralDirectorySize +=
                        46L
                                + entry.nameBytes.length
                                + getCentralExtraLength(
                                entry,
                                target
                        )
                                + entry.comment.length;

                entryCount++;
            }

            if (centralDirectoryOffset
                    > 0xffffffffL) {

                throw new IOException(
                        "APK demasiado grande para ZIP32."
                );
            }

            if (centralDirectorySize
                    > 0xffffffffL) {

                throw new IOException(
                        "Directorio ZIP demasiado grande."
                );
            }

            // -------------------------------------------------
            // CREAR SALIDA
            // -------------------------------------------------

            output =
                    new FileOutputStream(
                            outputApk
                    );

            /*
             * =================================================
             * SEGUNDA PASADA
             *
             * Ahora sí escribimos.
             * =================================================
             */

            for (int i = 0;
                 i < zipInfo.entries.size();
                 i++) {

                ZipEntryInfo entry =
                        zipInfo.entries.get(i);

                if (entry.removed) {
                    continue;
                }

                long newOffset =
                        newOffsets[i];

                if (entry == target) {

                    writeNewDexEntry(
                            output,
                            entry,
                            newDex,
                            newDexSize,
                            newDexCrc
                    );

                } else {

                    /*
                     * Copia BINARIA exacta de la entrada
                     * local original.
                     */
                    long localSize =
                            getLocalEntryTotalSize(
                                    input,
                                    entry
                            );

                    copyRange(
                            input,
                            output,
                            entry.localHeaderOffset,
                            localSize
                    );
                }

                /*
                 * Evita warning de compilación y deja claro
                 * que newOffset representa el offset calculado.
                 */
                if (newOffset < 0) {

                    throw new IOException(
                            "Offset ZIP inválido."
                    );
                }
            }

            // -------------------------------------------------
            // DIRECTORIO CENTRAL
            // -------------------------------------------------

            for (int i = 0;
                 i < zipInfo.entries.size();
                 i++) {

                ZipEntryInfo entry =
                        zipInfo.entries.get(i);

                if (entry.removed) {
                    continue;
                }

                long newOffset =
                        newOffsets[i];

                writeCentralEntry(
                        output,
                        entry,
                        newOffset,
                        target,
                        newDexSize,
                        newDexCrc
                );
            }

            // -------------------------------------------------
            // EOCD
            // -------------------------------------------------

            writeInt(
                    output,
                    END_OF_CENTRAL_DIRECTORY
            );

            writeShort(
                    output,
                    0
            );

            writeShort(
                    output,
                    0
            );

            writeShort(
                    output,
                    entryCount
            );

            writeShort(
                    output,
                    entryCount
            );

            writeInt(
                    output,
                    (int) centralDirectorySize
            );

            writeInt(
                    output,
                    (int) centralDirectoryOffset
            );

            byte[] archiveComment =
                    zipInfo.archiveComment;

            if (archiveComment == null) {
                archiveComment =
                        new byte[0];
            }

            if (archiveComment.length
                    > 65535) {

                archiveComment =
                        new byte[0];
            }

            writeShort(
                    output,
                    archiveComment.length
            );

            if (archiveComment.length > 0) {

                output.write(
                        archiveComment
                );
            }

            output.flush();

        } finally {

            if (output != null) {

                try {
                    output.close();
                } catch (Exception ignored) {
                }
            }

            if (input != null) {

                try {
                    input.close();
                } catch (Exception ignored) {
                }
            }
        }

        // -----------------------------------------------------
        // VERIFICACIÓN
        // -----------------------------------------------------

        if (!outputApk.exists()) {

            throw new IOException(
                    "No se creó el APK."
            );
        }

        if (outputApk.length() == 0) {

            throw new IOException(
                    "El APK resultante está vacío."
            );
        }

        verifyOutput(
                outputApk,
                dexName
        );

        return outputApk;
    }

    // =========================================================
    // ESCRIBIR NUEVO DEX
    // =========================================================

    private void writeNewDexEntry(
            FileOutputStream output,
            ZipEntryInfo originalEntry,
            File newDex,
            long newDexSize,
            long newDexCrc
    ) throws Exception {

        byte[] nameBytes =
                originalEntry.nameBytes;

        byte[] extra =
                getTargetExtra(
                        originalEntry
                );

        /*
         * -----------------------------------------------------
         * LOCAL HEADER
         * -----------------------------------------------------
         */

        writeInt(
                output,
                LOCAL_FILE_HEADER
        );

        /*
         * Versión mínima ZIP.
         */
        writeShort(
                output,
                20
        );

        /*
         * Quitamos data descriptor.
         */
        writeShort(
                output,
                originalEntry.flags
                        & ~0x0008
        );

        /*
         * STORED.
         */
        writeShort(
                output,
                0
        );

        writeShort(
                output,
                originalEntry.modTime
        );

        writeShort(
                output,
                originalEntry.modDate
        );

        writeInt(
                output,
                (int) newDexCrc
        );

        writeInt(
                output,
                (int) newDexSize
        );

        writeInt(
                output,
                (int) newDexSize
        );

        writeShort(
                output,
                nameBytes.length
        );

        writeShort(
                output,
                extra.length
        );

        output.write(
                nameBytes
        );

        if (extra.length > 0) {

            output.write(
                    extra
            );
        }

        /*
         * -----------------------------------------------------
         * DATOS DEL DEX
         * -----------------------------------------------------
         */

        FileInputStream input =
                new FileInputStream(
                        newDex
                );

        try {

            byte[] buffer =
                    new byte[BUFFER_SIZE];

            int read;

            while ((read =
                    input.read(buffer))
                    != -1) {

                output.write(
                        buffer,
                        0,
                        read
                );
            }

        } finally {

            input.close();
        }
    }

    // =========================================================
    // ESCRIBIR ENTRADA CENTRAL
    // =========================================================

    private void writeCentralEntry(
            FileOutputStream output,
            ZipEntryInfo entry,
            long newLocalOffset,
            ZipEntryInfo target,
            long newDexSize,
            long newDexCrc
    ) throws Exception {

        boolean isTarget =
                entry == target;

        byte[] nameBytes =
                entry.nameBytes;

        byte[] extra =
                isTarget
                        ? getTargetExtra(entry)
                        : entry.extra;

        byte[] comment =
                entry.comment;

        writeInt(
                output,
                CENTRAL_FILE_HEADER
        );

        /*
         * Version made by original.
         */
        writeShort(
                output,
                entry.versionMadeBy
        );

        if (isTarget) {

            writeShort(
                    output,
                    20
            );

        } else {

            writeShort(
                    output,
                    entry.versionNeeded
            );
        }

        int flags =
                entry.flags;

        if (isTarget) {

            flags &= ~0x0008;
        }

        writeShort(
                output,
                flags
        );

        int method =
                entry.method;

        if (isTarget) {

            method = 0;
        }

        writeShort(
                output,
                method
        );

        writeShort(
                output,
                entry.modTime
        );

        writeShort(
                output,
                entry.modDate
        );

        if (isTarget) {

            writeInt(
                    output,
                    (int) newDexCrc
            );

            writeInt(
                    output,
                    (int) newDexSize
            );

            writeInt(
                    output,
                    (int) newDexSize
            );

        } else {

            writeInt(
                    output,
                    (int) entry.crc
            );

            writeInt(
                    output,
                    (int) entry.compressedSize
            );

            writeInt(
                    output,
                    (int) entry.uncompressedSize
            );
        }

        writeShort(
                output,
                nameBytes.length
        );

        writeShort(
                output,
                extra.length
        );

        writeShort(
                output,
                comment.length
        );

        writeShort(
                output,
                entry.diskNumberStart
        );

        writeShort(
                output,
                entry.internalAttributes
        );

        writeInt(
                output,
                (int) entry.externalAttributes
        );

        writeInt(
                output,
                (int) newLocalOffset
        );

        output.write(
                nameBytes
        );

        if (extra.length > 0) {

            output.write(
                    extra
            );
        }

        if (comment.length > 0) {

            output.write(
                    comment
            );
        }
    }

    // =========================================================
    // LEER INFORMACIÓN ZIP
    // =========================================================

    private ZipInfo readZipInfo(
            RandomAccessFile raf
    ) throws Exception {

        long eocd =
                findEndOfCentralDirectory(
                        raf
                );

        if (eocd < 0) {

            throw new IOException(
                    "No se encontró el EOCD del APK."
            );
        }

        raf.seek(
                eocd + 4
        );

        int diskNumber =
                readUnsignedShort(
                        raf
                );

        int centralDisk =
                readUnsignedShort(
                        raf
                );

        int entriesOnDisk =
                readUnsignedShort(
                        raf
                );

        int totalEntries =
                readUnsignedShort(
                        raf
                );

        long centralSize =
                readUnsignedInt(
                        raf
                );

        long centralOffset =
                readUnsignedInt(
                        raf
                );

        int commentLength =
                readUnsignedShort(
                        raf
                );

        if (diskNumber != 0
                || centralDisk != 0) {

            throw new IOException(
                    "ZIP multi-disco no soportado."
            );
        }

        /*
         * ZIP64 no se implementa aquí.
         */
        if (entriesOnDisk == 0xffff
                || totalEntries == 0xffff
                || centralSize == 0xffffffffL
                || centralOffset == 0xffffffffL) {

            throw new IOException(
                    "APK ZIP64 no soportado."
            );
        }

        ZipInfo info =
                new ZipInfo();

        info.centralDirectoryOffset =
                centralOffset;

        info.centralDirectorySize =
                centralSize;

        info.archiveComment =
                new byte[commentLength];

        if (commentLength > 0) {

            raf.seek(
                    eocd + 22
            );

            raf.readFully(
                    info.archiveComment
            );
        }

        raf.seek(
                centralOffset
        );

        for (int i = 0;
             i < totalEntries;
             i++) {

            int signature =
                    readInt(
                            raf
                    );

            if (signature
                    != CENTRAL_FILE_HEADER) {

                throw new IOException(
                        "Entrada central ZIP inválida."
                );
            }

            ZipEntryInfo entry =
                    new ZipEntryInfo();

            entry.versionMadeBy =
                    readUnsignedShort(
                            raf
                    );

            entry.versionNeeded =
                    readUnsignedShort(
                            raf
                    );

            entry.flags =
                    readUnsignedShort(
                            raf
                    );

            entry.method =
                    readUnsignedShort(
                            raf
                    );

            entry.modTime =
                    readUnsignedShort(
                            raf
                    );

            entry.modDate =
                    readUnsignedShort(
                            raf
                    );

            entry.crc =
                    readUnsignedInt(
                            raf
                    );

            entry.compressedSize =
                    readUnsignedInt(
                            raf
                    );

            entry.uncompressedSize =
                    readUnsignedInt(
                            raf
                    );

            int nameLength =
                    readUnsignedShort(
                            raf
                    );

            int extraLength =
                    readUnsignedShort(
                            raf
                    );

            int commentLen =
                    readUnsignedShort(
                            raf
                    );

            entry.diskNumberStart =
                    readUnsignedShort(
                            raf
                    );

            entry.internalAttributes =
                    readUnsignedShort(
                            raf
                    );

            entry.externalAttributes =
                    readUnsignedInt(
                            raf
                    );

            entry.localHeaderOffset =
                    readUnsignedInt(
                            raf
                    );

            entry.nameBytes =
                    new byte[nameLength];

            if (nameLength > 0) {

                raf.readFully(
                        entry.nameBytes
                );
            }

            /*
             * Los APK normalmente usan UTF-8.
             */
            entry.name =
                    decodeZipName(
                            entry.nameBytes,
                            entry.flags
                    );

            entry.extra =
                    new byte[extraLength];

            if (extraLength > 0) {

                raf.readFully(
                        entry.extra
                );
            }

            entry.comment =
                    new byte[commentLen];

            if (commentLen > 0) {

                raf.readFully(
                        entry.comment
                );
            }

            /*
             * No soportamos entradas ZIP64.
             */
            if (containsZip64Extra(
                    entry.extra
            )) {

                throw new IOException(
                        "Entrada ZIP64 no soportada:\n"
                                + entry.name
                );
            }

            info.entries.add(
                    entry
            );
        }

        return info;
    }

    // =========================================================
    // TAMAÑO DE UNA ENTRADA LOCAL
    // =========================================================

    private long getLocalEntryTotalSize(
            RandomAccessFile raf,
            ZipEntryInfo entry
    ) throws Exception {

        raf.seek(
                entry.localHeaderOffset
        );

        int signature =
                readInt(
                        raf
                );

        if (signature
                != LOCAL_FILE_HEADER) {

            throw new IOException(
                    "Local header inválido:\n"
                            + entry.name
            );
        }

        readUnsignedShort(
                raf
        );

        int flags =
                readUnsignedShort(
                        raf
                );

        readUnsignedShort(
                raf
        );

        readUnsignedShort(
                raf
        );

        readUnsignedShort(
                raf
        );

        readUnsignedInt(
                raf
        );

        readUnsignedInt(
                raf
        );

        readUnsignedInt(
                raf
        );

        int nameLength =
                readUnsignedShort(
                        raf
                );

        int extraLength =
                readUnsignedShort(
                        raf
                );

        long headerSize =
                30L
                        + nameLength
                        + extraLength;

        long total =
                headerSize
                        + entry.compressedSize;

        /*
         * Bit 3 = data descriptor.
         *
         * El descriptor puede tener:
         *
         * 12 bytes sin firma
         * o
         * 16 bytes con firma.
         *
         * Determinamos cuál existe mirando el valor después
         * de los datos.
         */
        if ((flags & 0x0008) != 0) {

            long descriptorOffset =
                    entry.localHeaderOffset
                            + headerSize
                            + entry.compressedSize;

            raf.seek(
                    descriptorOffset
            );

            int possibleSignature =
                    readInt(
                            raf
                    );

            if (possibleSignature
                    == 0x08074b50) {

                total += 16;

            } else {

                total += 12;
            }
        }

        return total;
    }

    // =========================================================
    // COPIAR BYTES EXACTAMENTE
    // =========================================================

    private void copyRange(
            RandomAccessFile input,
            FileOutputStream output,
            long offset,
            long length
    ) throws Exception {

        input.seek(
                offset
        );

        byte[] buffer =
                new byte[BUFFER_SIZE];

        long remaining =
                length;

        while (remaining > 0) {

            int wanted =
                    (int) Math.min(
                            buffer.length,
                            remaining
                    );

            int read =
                    input.read(
                            buffer,
                            0,
                            wanted
                    );

            if (read < 0) {

                throw new IOException(
                        "Fin inesperado del APK."
                );
            }

            output.write(
                    buffer,
                    0,
                    read
            );

            remaining -=
                    read;
        }
    }

    // =========================================================
    // CRC32
    // =========================================================

    private long calculateCrc32(
            File file
    ) throws Exception {

        CRC32 crc =
                new CRC32();

        FileInputStream input =
                new FileInputStream(
                        file
                );

        try {

            byte[] buffer =
                    new byte[BUFFER_SIZE];

            int read;

            while ((read =
                    input.read(buffer))
                    != -1) {

                crc.update(
                        buffer,
                        0,
                        read
                );
            }

        } finally {

            input.close();
        }

        return crc.getValue();
    }

    // =========================================================
    // EXTRA DEL DEX
    // =========================================================

    private byte[] getTargetExtra(
            ZipEntryInfo entry
    ) {

        /*
         * Conservamos el extra original solamente si no contiene
         * información ZIP64.
         *
         * Esto permite mantener, por ejemplo, padding/alignment
         * que pudiera existir en la entrada original.
         */
        if (entry.extra == null) {
            return new byte[0];
        }

        return entry.extra;
    }

    private int getTargetExtraLength(
            ZipEntryInfo entry
    ) {

        return getTargetExtra(
                entry
        ).length;
    }

    private int getCentralExtraLength(
            ZipEntryInfo entry,
            ZipEntryInfo target
    ) {

        if (entry == target) {

            return getTargetExtra(
                    entry
            ).length;
        }

        return entry.extra == null
                ? 0
                : entry.extra.length;
    }

    // =========================================================
    // DETECTAR ZIP64
    // =========================================================

    private boolean containsZip64Extra(
            byte[] extra
    ) {

        if (extra == null) {
            return false;
        }

        int offset = 0;

        while (offset + 4 <= extra.length) {

            int id =
                    (extra[offset] & 0xff)
                            | ((extra[offset + 1] & 0xff) << 8);

            int size =
                    (extra[offset + 2] & 0xff)
                            | ((extra[offset + 3] & 0xff) << 8);

            if (id == 0x0001) {
                return true;
            }

            offset +=
                    4 + size;
        }

        return false;
    }

    // =========================================================
    // NOMBRE ZIP
    // =========================================================

    private String decodeZipName(
            byte[] bytes,
            int flags
    ) throws Exception {

        /*
         * Bit 11 = UTF-8.
         *
         * APKs modernos normalmente lo utilizan.
         */
        if ((flags & 0x0800) != 0) {

            return new String(
                    bytes,
                    "UTF-8"
            );
        }

        /*
         * CP437 es el charset tradicional ZIP.
         */
        try {

            return new String(
                    bytes,
                    "Cp437"
            );

        } catch (Exception ignored) {

            return new String(
                    bytes,
                    "UTF-8"
            );
        }
    }

    // =========================================================
    // EOCD
    // =========================================================

    private long findEndOfCentralDirectory(
            RandomAccessFile raf
    ) throws Exception {

        long fileLength =
                raf.length();

        long start =
                Math.max(
                        0,
                        fileLength
                                - MAX_EOCD_SEARCH
                );

        long position =
                fileLength - 22;

        while (position >= start) {

            raf.seek(
                    position
            );

            int signature =
                    readInt(
                            raf
                    );

            if (signature
                    == END_OF_CENTRAL_DIRECTORY) {

                return position;
            }

            position--;
        }

        return -1;
    }

    // =========================================================
    // FIRMAS V1
    // =========================================================

    private boolean isSignatureFile(
            String name
    ) {

        if (name == null) {
            return false;
        }

        String upper =
                name.toUpperCase(
                        Locale.ROOT
                );

        if (!upper.startsWith(
                "META-INF/"
        )) {

            return false;
        }

        /*
         * Firma JAR / APK V1.
         *
         * Se eliminan porque quedan inválidas después
         * de modificar el APK.
         */
        if (upper.endsWith(".RSA")) {
            return true;
        }

        if (upper.endsWith(".DSA")) {
            return true;
        }

        if (upper.endsWith(".EC")) {
            return true;
        }

        if (upper.endsWith(".SF")) {
            return true;
        }

        if (upper.equals(
                "META-INF/MANIFEST.MF"
        )) {

            return true;
        }

        return false;
    }

    // =========================================================
    // VALIDACIONES
    // =========================================================

    private void validateArguments(
            File originalApk,
            File newDex,
            String dexName,
            File outputApk
    ) throws Exception {

        if (originalApk == null
                || !originalApk.exists()
                || !originalApk.isFile()) {

            throw new IOException(
                    "APK original no encontrado."
            );
        }

        if (originalApk.length() == 0) {

            throw new IOException(
                    "El APK original está vacío."
            );
        }

        if (newDex == null
                || !newDex.exists()
                || !newDex.isFile()) {

            throw new IOException(
                    "DEX nuevo no encontrado."
            );
        }

        if (newDex.length() == 0) {

            throw new IOException(
                    "El DEX nuevo está vacío."
            );
        }

        if (dexName == null
                || dexName.trim().isEmpty()) {

            throw new IOException(
                    "Nombre del DEX inválido."
            );
        }

        if (outputApk == null) {

            throw new IOException(
                    "APK de salida inválido."
            );
        }

        /*
         * El APK de salida no puede ser el mismo archivo
         * que el original.
         */
        if (originalApk
                .getCanonicalPath()
                .equals(
                        outputApk
                                .getCanonicalPath()
                )) {

            throw new IOException(
                    "El APK de salida debe ser diferente "
                            + "del APK original."
            );
        }
    }

    // =========================================================
    // VERIFICAR RESULTADO
    // =========================================================

    private void verifyOutput(
            File apk,
            String dexName
    ) throws Exception {

        RandomAccessFile raf =
                new RandomAccessFile(
                        apk,
                        "r"
                );

        try {

            ZipInfo info =
                    readZipInfo(
                            raf
                    );

            boolean found =
                    false;

            for (ZipEntryInfo entry :
                    info.entries) {

                if (dexName.equals(
                        entry.name)) {

                    found = true;
                    break;
                }
            }

            if (!found) {

                throw new IOException(
                        "El APK resultante no contiene:\n"
                                + dexName
                );
            }

        } finally {

            raf.close();
        }
    }

    // =========================================================
    // LECTURA LITTLE-ENDIAN
    // =========================================================

    private static int readInt(
            RandomAccessFile raf
    ) throws Exception {

        int b0 =
                raf.read();

        int b1 =
                raf.read();

        int b2 =
                raf.read();

        int b3 =
                raf.read();

        if ((b0 | b1 | b2 | b3) < 0) {

            throw new IOException(
                    "Fin inesperado del archivo."
            );
        }

        return
                b0
                        | (b1 << 8)
                        | (b2 << 16)
                        | (b3 << 24);
    }

    private static long readUnsignedInt(
            RandomAccessFile raf
    ) throws Exception {

        return readInt(
                raf
        ) & 0xffffffffL;
    }

    private static int readUnsignedShort(
            RandomAccessFile raf
    ) throws Exception {

        int b0 =
                raf.read();

        int b1 =
                raf.read();

        if ((b0 | b1) < 0) {

            throw new IOException(
                    "Fin inesperado del archivo."
            );
        }

        return
                b0
                        | (b1 << 8);
    }

    // =========================================================
    // ESCRITURA LITTLE-ENDIAN
    // =========================================================

    private static void writeInt(
            FileOutputStream output,
            int value
    ) throws Exception {

        output.write(
                value & 0xff
        );

        output.write(
                (value >>> 8) & 0xff
        );

        output.write(
                (value >>> 16) & 0xff
        );

        output.write(
                (value >>> 24) & 0xff
        );
    }

    private static void writeShort(
            FileOutputStream output,
            int value
    ) throws Exception {

        output.write(
                value & 0xff
        );

        output.write(
                (value >>> 8) & 0xff
        );
    }
}